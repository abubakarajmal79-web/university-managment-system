# University Management System

A full-stack University Management System built with **Node.js, Express.js, MySQL, HTML, CSS and JavaScript**.

## Features

- User authentication with JWT
- Student management
- Teacher management
- Course management
- Attendance management
- Fees and payments management
- Results management
- Dashboard statistics
- Events and notices
- Exam-related pages
- REST API backend

## Tech Stack

### Backend
- Node.js
- Express.js
- MySQL / MySQL2
- JWT Authentication
- bcryptjs
- Helmet, CORS, Morgan and rate limiting

### Frontend
- HTML5
- CSS3
- JavaScript

## Project Structure

```text
University Management System/
├── client/                 # Frontend pages
├── server/                 # Express backend
│   ├── config/             # Database configuration
│   ├── controllers/        # Business logic
│   ├── middleware/         # Authentication and middleware
│   ├── routes/             # API routes
│   ├── utils/              # Utility functions
│   ├── app.js
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── .gitignore
└── README.md
```

## Setup

### 1. Clone the repository

```bash
git clone YOUR_REPOSITORY_URL
cd "DBMS project/server"
```

### 2. Install backend dependencies

```bash
npm install
```

### 3. Configure environment variables

Copy `.env.example` to `.env` and update the database credentials and JWT secret.

### 4. Create the MySQL database

Create a database named:

```text
university_management_system
```

Then create/import the required tables for the application.

### 5. Start the server

Development:

```bash
npm run dev
```

Production/start:

```bash
npm start
```

The backend uses port **5000** by default.

## Important

The `.env` file is intentionally excluded from GitHub. Do not upload database passwords, JWT secrets, API keys or other private credentials.

A MySQL `.sql` database dump is not included in this repository yet. If you have one, add it separately before sharing the project with others.
