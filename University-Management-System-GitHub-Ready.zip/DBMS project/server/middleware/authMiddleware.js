const jwt = require("jsonwebtoken");

const protect = (req, res, next) => {
    let token;

    // Check Authorization Header
    if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
        token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "No Token Provided, Authorization Denied"
        });
    }

    try {
        // Safe check and string sanitization
        token = token.replace(/^"|"$/g, '').trim();

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; 
        next();
    } catch (err) {
        console.log("JWT Verification Error Log:", err.message);
        return res.status(401).json({
            success: false,
            message: "Invalid or Expired Token"
        });
    }
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: "Access Denied: Required permissions missing"
            });
        }
        next();
    };
};

// 🔥 STRICT EXPORTS MAP
module.exports = {
    protect,
    authorize
};