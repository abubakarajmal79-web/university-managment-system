const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// @desc    Get All Campus Events
exports.getAllEvents = asyncHandler(async (req, res) => {
    try {
        // Database ke 'event_name' aur 'venue' ko frontend ke 'event_title' aur 'location' mein map kiya
        const [events] = await db.query(
            "SELECT event_id AS id, event_name AS event_title, description, event_date, venue AS location FROM events ORDER BY event_date ASC"
        );
        return res.status(200).json({ success: true, count: events.length, data: events });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// @desc    Create a New Campus Event
exports.createEvent = asyncHandler(async (req, res) => {
    const { event_title, description, event_date, location } = req.body;

    if (!event_title || !event_date) {
        return res.status(400).json({ success: false, message: "Event title and date are required" });
    }

    // Database mein wahi column names use karein jo table mein hain
    const sql = "INSERT INTO events (event_name, description, event_date, venue) VALUES (?, ?, ?, ?)";
    const values = [event_title, description || "", event_date, location || "Campus"];

    const [result] = await db.query(sql, values);

    res.status(201).json({ 
        success: true, 
        message: "Event scheduled successfully", 
        eventId: result.insertId 
    });
});

// @desc    Delete an Event
exports.deleteEvent = asyncHandler(async (req, res) => {
    const eventId = req.params.id;
    try {
        await db.query("DELETE FROM events WHERE event_id = ?", [eventId]);
        res.status(200).json({ success: true, message: "Event deleted successfully" });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});