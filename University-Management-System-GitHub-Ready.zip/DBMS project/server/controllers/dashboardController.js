const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// @desc    Get Admin Dashboard Total Statistics
// @route   GET /api/v1/dashboard/stats
const getDashboardStats = asyncHandler(async (req, res) => {
    // 1. Total Students Count
    const [[studentsCount]] = await db.query("SELECT COUNT(*) as total FROM users WHERE role = 'student'");
    
    // 2. Total Teachers Count
    const [[teachersCount]] = await db.query("SELECT COUNT(*) as total FROM users WHERE role = 'teacher'");
    
    // 3. Total Courses Count
    const [[coursesCount]] = await db.query("SELECT COUNT(*) as total FROM courses");

    res.status(200).json({
        success: true,
        stats: {
            totalStudents: studentsCount?.total || 0,
            totalTeachers: teachersCount?.total || 0,
            totalCourses: coursesCount?.total || 0
        }
    });
});

module.exports = {
    getDashboardStats
};