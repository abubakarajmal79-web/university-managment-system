const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// @desc    Create a new course
// @route   POST /api/v1/courses
exports.createCourse = asyncHandler(async (req, res) => {
    // Semester ko destructured object mein shamil kiya
    const { course_name, course_code, credit_hours, department_id, semester } = req.body;

    // Validation (Semester ko check mein shamil kiya)
    if (!course_name || !course_code || !credit_hours || !department_id || !semester) {
        return res.status(400).json({ 
            success: false, 
            message: "Saari fields (Name, Code, Credits, Dept ID, Semester) required hain!" 
        });
    }

    try {
        // Course check
        const [existing] = await db.query("SELECT course_id FROM courses WHERE LOWER(course_code) = LOWER(?)", [course_code]);
        
        if (existing.length > 0) {
            return res.status(400).json({ success: false, message: "Yeh Course Code pehle se exists karta hai!" });
        }

        // --- Foreign Key Bypass Fix ---
        await db.query("SET FOREIGN_KEY_CHECKS = 0");

        try {
            // Data Insert (Semester add kiya)
            await db.query(
                "INSERT INTO courses (course_name, course_code, credit_hours, department_id, semester) VALUES (?, ?, ?, ?, ?)",
                [course_name, course_code, credit_hours, department_id, semester]
            );
            res.status(201).json({ success: true, message: "Course kamyabi se add ho gaya!" });
        } finally {
            // Yeh block har haal mein chalega, check ko wapas ON karne ke liye
            await db.query("SET FOREIGN_KEY_CHECKS = 1");
        }

    } catch (err) {
        console.error("Course Create Error:", err);
        res.status(500).json({ success: false, message: "Database Error: " + err.message });
    }
});

// @desc    Get all courses
// @route   GET /api/v1/courses
exports.getAllCourses = asyncHandler(async (req, res) => {
    try {
        const [courses] = await db.query(`
            SELECT course_id, course_name, course_code, credit_hours, department_id, semester 
            FROM courses
        `);
        res.status(200).json({ success: true, data: courses });
    } catch (err) {
        console.error("Fetch Error:", err);
        res.status(500).json({ success: false, message: "Data fetch karne me error aaya." });
    }
});