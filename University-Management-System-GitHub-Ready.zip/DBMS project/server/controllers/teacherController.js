const asyncHandler = require("express-async-handler");
const db = require("../config/db");
const bcrypt = require("bcryptjs");

// @desc    Register a new Teacher
// @route   POST /api/v1/teachers
exports.registerTeacher = asyncHandler(async (req, res) => {
    // 1. Naye fields ko destructure karein
    const { 
        full_name, email, password, designation, department, 
        phone, address, cnic, gender, qualification, salary, joining_date 
    } = req.body;

    // Basic Validation
    if (!full_name || !email || !password) {
        return res.status(400).json({ success: false, message: "Name, Email aur Password zaroori hain!" });
    }

    try {
        await db.query("START TRANSACTION");

        // Check if user exists
        const [existing] = await db.query("SELECT id FROM users WHERE email = ?", [email]);
        if (existing.length > 0) {
            await db.query("ROLLBACK");
            return res.status(400).json({ success: false, message: "Email pehle se register hai!" });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Insert into users
        const [userResult] = await db.query(
            "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, 'teacher')",
            [full_name, email, hashedPassword]
        );
        const userId = userResult.insertId;

        // 2. Updated Insert Query (Saari fields shamil hain)
        await db.query(
            `INSERT INTO teacher_profiles 
            (user_id, cnic, gender, qualification, designation, department, salary, phone, address, joining_date) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [userId, cnic, gender, qualification, designation, department, salary, phone, address, joining_date]
        );

        await db.query("COMMIT");
        res.status(201).json({ success: true, message: "Teacher register ho chuka hai!" });
    } catch (err) {
        await db.query("ROLLBACK");
        console.error("Teacher Registration Error:", err);
        res.status(500).json({ success: false, message: "Server error, check console." });
    }
});

// @desc    Get All Teachers
// @route   GET /api/v1/teachers
exports.getAllTeachers = asyncHandler(async (req, res) => {
    try {
        const [teachers] = await db.query(`
            SELECT 
                u.id as user_id, 
                u.full_name, 
                u.email, 
                tp.designation, 
                tp.department, 
                tp.phone, 
                tp.address,
                tp.cnic,
                tp.gender,
                tp.qualification,
                tp.salary,
                tp.joining_date
            FROM users u
            JOIN teacher_profiles tp ON u.id = tp.user_id
            WHERE u.role = 'teacher'
        `);
        res.status(200).json({ success: true, data: teachers });
    } catch (err) {
        res.status(500).json({ success: false, message: "Data fetch karne mein error aaya." });
    }
});