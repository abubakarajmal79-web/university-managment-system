const bcrypt = require("bcryptjs");
const asyncHandler = require("express-async-handler");
const validator = require("validator");
const jwt = require("jsonwebtoken");
const db = require("../config/db");

// @desc    Register User
// @route   POST /api/v1/auth/register
exports.register = asyncHandler(async (req, res) => {
    console.log("REGISTER BODY =", req.body);
    const { full_name, email, password, role } = req.body;

    if (!full_name || !email || !password) {
        return res.status(400).json({ success: false, message: "All fields are required" });
    }

    if (!validator.isEmail(email)) {
        return res.status(400).json({ success: false, message: "Invalid Email" });
    }

    const [exist] = await db.query("SELECT id FROM users WHERE email = ?", [email]);
    if (exist.length > 0) {
        return res.status(400).json({ success: false, message: "Email Already Exists" });
    }

    const userRole = role || "student";
    const hash = await bcrypt.hash(password, 10);
    const [result] = await db.query(
        "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)",
        [full_name, email, hash, userRole]
    );

    const userId = result.insertId;
    const token = jwt.sign({ id: userId, role: userRole }, process.env.JWT_SECRET, { expiresIn: "7d" });

    res.status(201).json({
        success: true,
        message: "User Registered Successfully",
        token
    });
});

// @desc    Login User
// @route   POST /api/v1/auth/login
exports.login = asyncHandler(async (req, res) => {
    console.log("LOGIN BODY =", req.body);
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ success: false, message: "Please provide email and password" });
    }

    const [users] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
    if (users.length === 0) {
        return res.status(401).json({ success: false, message: "Invalid Credentials" });
    }

    const user = users[0];

    if (user.role !== "admin") {
        return res.status(403).json({
            success: false,
            message: "Access Denied: Only Admins can login to this portal"
        });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        return res.status(401).json({ success: false, message: "Invalid Credentials" });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

    res.status(200).json({
        success: true,
        message: "Logged In Successfully as Admin",
        token,
        user: {
            id: user.id,
            full_name: user.full_name,
            email: user.email,
            role: user.role
        }
    });
});

// @desc    Logout User
// @route   POST /api/v1/auth/logout
exports.logout = asyncHandler(async (req, res) => {
    res.status(200).json({
        success: true,
        message: "Logged Out Successfully"
    });
});

// @desc    Get User Profile
// @route   GET /api/v1/auth/profile
exports.profile = asyncHandler(async (req, res) => {
    const [users] = await db.query("SELECT id, full_name, email, role, status, created_at FROM users WHERE id = ?", [req.user.id]);
    
    if (users.length === 0) {
        return res.status(404).json({ success: false, message: "User not found" });
    }

    res.status(200).json({
        success: true,
        user: users[0]
    });
});