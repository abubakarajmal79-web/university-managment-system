const db = require('../config/db');

exports.registerStudent = async (req, res) => {
    try {
        const { 
            full_name, father_name, roll_number, gender, dob, 
            department, program, semester, session, phone, address 
        } = req.body;

        // 1. Create User first (using your table schema)
        // Roll number ko email bana rahe hain taaki unique rahe
        const userEmail = `${roll_number}@university.edu`; 
        const password = "123456"; // Default password
        const role = "student";

        const userSql = "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)";
        const [userResult] = await db.query(userSql, [full_name, userEmail, password, role]);
        
        // 2. Get the new user ID
        const newUserId = userResult.insertId; 

        // 3. Create Student Profile (linking via user_id)
        const sql = `INSERT INTO student_profiles 
        (full_name, father_name, user_id, roll_number, gender, dob, department, 
         program, semester, session, phone, address) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

        const values = [full_name, father_name, newUserId, roll_number, gender, dob, department, program, semester, session, phone, address];

        await db.query(sql, values);
        
        res.status(201).json({ success: true, message: "Student Registered Successfully!" });

    } catch (err) {
        console.error("Database Error:", err);
        // Duplicate Entry Error Check
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ success: false, message: "Error: Is Roll Number ya Email ka student pehle se majood hai." });
        }
        res.status(500).json({ success: false, message: "Database Error: " + err.message });
    }
};

// --- GET ALL STUDENTS ---
exports.getAllStudents = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM student_profiles");
        res.status(200).json({ success: true, data: rows });
    } catch (err) {
        console.error("Database Error:", err);
        res.status(500).json({ success: false, message: "Database Error" });
    }
};