const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// 1. Get All Results
const getAllResults = asyncHandler(async (req, res) => {
    try {
        // FIX: 'c.id' ki jagah 'c.course_id' use kiya hai kyunki aapka primary key 'course_id' hai.
        const sql = `
            SELECT 
                r.id AS result_id, 
                r.marks_obtained, 
                r.total_marks, 
                r.grade, 
                s.roll_number, 
                c.course_name 
            FROM exam_results r
            JOIN student_profiles s ON r.student_id = s.id
            JOIN courses c ON r.course_id = c.course_id
            ORDER BY r.id DESC
        `;
        
        const [results] = await db.query(sql);
        res.status(200).json({ success: true, data: results });
    } catch (error) {
        console.error("SQL Error:", error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 2. Create Result
const createResult = asyncHandler(async (req, res) => {
    const { student_roll, course_code, marks_obtained, total_marks, grade } = req.body;

    if (!student_roll || !course_code || !marks_obtained || !total_marks || !grade) {
        return res.status(400).json({ success: false, message: "All fields are required" });
    }

    try {
        const [studentRows] = await db.query("SELECT id FROM student_profiles WHERE roll_number = ?", [student_roll]);
        const [courseRows] = await db.query("SELECT course_id FROM courses WHERE course_code = ?", [course_code]);

        if (studentRows.length === 0 || courseRows.length === 0) {
            return res.status(404).json({ success: false, message: "Student or Course not found" });
        }

        await db.query(
            "INSERT INTO exam_results (student_id, course_id, marks_obtained, total_marks, grade) VALUES (?, ?, ?, ?, ?)",
            [studentRows[0].id, courseRows[0].course_id, marks_obtained, total_marks, grade]
        );
        res.status(201).json({ success: true, message: "Result created" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 3. Delete Result
const deleteResult = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        await db.query("DELETE FROM exam_results WHERE id = ?", [id]);
        res.status(200).json({ success: true, message: "Deleted successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// IMPORTANT: Teeno function yahan export hone chahiye
module.exports = { createResult, getAllResults, deleteResult };