const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// @desc    Get All Attendance Records
// @route   GET /api/v1/attendance
exports.getAllAttendance = asyncHandler(async (req, res) => {
    try {
        // Naye schema ke mutabiq columns select kiye hain
        const [records] = await db.query(`
            SELECT id, student_roll, date, status 
            FROM attendance 
            ORDER BY date DESC, id DESC
        `);

        res.status(200).json({
            success: true,
            count: records.length,
            data: records
        });
    } catch (error) {
        console.error("Fetch Attendance Error:", error);
        res.status(500).json({ success: false, message: "Error fetching data: " + error.message });
    }
});

// @desc    Mark Student Attendance
// @route   POST /api/v1/attendance
exports.markAttendance = asyncHandler(async (req, res) => {
    const { student_roll, date, status } = req.body;

    // Validation
    if (!student_roll || !date || !status) {
        return res.status(400).json({
            success: false,
            message: "Please provide Student Roll, Date and Status"
        });
    }

    try {
        // 1. Check karein ke is date aur roll number ka record pehle se hai?
        const [existing] = await db.query(
            "SELECT id FROM attendance WHERE student_roll = ? AND date = ?",
            [student_roll, date]
        );

        if (existing.length > 0) {
            // Update Existing Record (Using 'id' instead of 'attendance_id')
            await db.query(
                "UPDATE attendance SET status = ? WHERE id = ?",
                [status, existing[0].id]
            );
            return res.status(200).json({
                success: true,
                message: "Attendance updated successfully!"
            });
        }

        // 2. Insert New Record
        await db.query(
            "INSERT INTO attendance (student_roll, date, status) VALUES (?, ?, ?)",
            [student_roll, date, status]
        );

        res.status(201).json({
            success: true,
            message: "Attendance marked successfully!"
        });

    } catch (error) {
        console.error("Attendance Error:", error);
        res.status(500).json({
            success: false,
            message: "Database Error: " + error.message
        });
    }
});