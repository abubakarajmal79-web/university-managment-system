const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// 1. Create Notice
const createNotice = asyncHandler(async (req, res) => {
    const { title, description, publish_date } = req.body;

    if (!title || !description) {
        return res.status(400).json({ success: false, message: "Title and description are required" });
    }

    try {
        const sql = "INSERT INTO notices (title, description, publish_date) VALUES (?, ?, ?)";
        await db.query(sql, [title, description, publish_date || new Date()]);

        return res.status(201).json({ success: true, message: "Notice published successfully!" });
    } catch (error) {
        console.error("Notice Creation Error:", error);
        return res.status(500).json({ success: false, message: error.message });
    }
});

// 2. Get All Notices
const getAllNotices = asyncHandler(async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM notices ORDER BY notice_id DESC");
        return res.status(200).json({ success: true, data: rows });
    } catch (error) {
        console.error("Fetch Error:", error);
        return res.status(500).json({ success: false, message: error.message });
    }
});

// CRITICAL: Yeh export hona bahut zaroori hai
module.exports = {
    createNotice,
    getAllNotices
};