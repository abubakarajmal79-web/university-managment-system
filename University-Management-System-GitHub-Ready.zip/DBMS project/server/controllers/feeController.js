const asyncHandler = require("express-async-handler");
const db = require("../config/db");

// 1. Create Fee Voucher
exports.createFeeVoucher = asyncHandler(async (req, res) => {
    // Frontend se 'student_id' aana chahiye (dropdown value)
    const { student_id, total_fee, paid_fee, due_date } = req.body;
    
    // Validation
    if (!student_id || !total_fee || !due_date) {
        return res.status(400).json({ success: false, message: "Student ID, Total Fee, and Due Date are required" });
    }

    const paid = paid_fee || 0;
    const remaining = total_fee - paid;

    try {
        const sql = `INSERT INTO fees (student_id, total_fee, paid_fee, remaining_fee, due_date, status) VALUES (?, ?, ?, ?, ?, ?)`;
        const status = remaining <= 0 ? 'Paid' : 'Unpaid';
        
        await db.query(sql, [student_id, total_fee, paid, remaining, due_date, status]);
        
        res.status(201).json({ success: true, message: "Fee voucher generated successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Database Error: " + error.message });
    }
});

// 2. Get All Fees
exports.getAllFees = asyncHandler(async (req, res) => {
    try {
        const [fees] = await db.query(`
            SELECT f.id, u.full_name as student_name, s.roll_number, f.total_fee, f.paid_fee, f.remaining_fee, f.due_date, f.status
            FROM fees f
            LEFT JOIN student_profiles s ON f.student_id = s.id
            LEFT JOIN users u ON s.user_id = u.id
            ORDER BY f.id DESC
        `);
        res.status(200).json({ success: true, data: fees });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 3. Update Fee (Payment/Status)
exports.updateFeeStatus = asyncHandler(async (req, res) => {
    const { paid_fee } = req.body;
    const feeId = req.params.id;

    try {
        // Fetch current fee details to calculate new remaining
        const [rows] = await db.query("SELECT total_fee FROM fees WHERE id = ?", [feeId]);
        if (rows.length === 0) return res.status(404).json({ success: false, message: "Fee not found" });

        const total_fee = rows[0].total_fee;
        const new_remaining = total_fee - paid_fee;
        const status = new_remaining <= 0 ? 'Paid' : 'Unpaid';

        await db.query(
            "UPDATE fees SET paid_fee = ?, remaining_fee = ?, status = ? WHERE id = ?", 
            [paid_fee, new_remaining, status, feeId]
        );

        res.status(200).json({ success: true, message: "Payment updated successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 4. Delete Fee Voucher
exports.deleteFee = asyncHandler(async (req, res) => {
    try {
        const [result] = await db.query("DELETE FROM fees WHERE id = ?", [req.params.id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: "Fee record not found" });
        }
        res.status(200).json({ success: true, message: "Voucher deleted successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});