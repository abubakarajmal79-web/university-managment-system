const express = require("express");
const router = express.Router();
const { 
    createFeeVoucher, 
    getAllFees, 
    updateFeeStatus, 
    deleteFee 
} = require("../controllers/feeController");

// Ye URL automatic 'api/v1/fees' ke saath jude hain
router.post("/", createFeeVoucher);
router.get("/", getAllFees);
router.put("/:id", updateFeeStatus);
router.delete("/:id", deleteFee);

module.exports = router;