const express = require('express');
const router = express.Router();

// CRITICAL: Import karte waqt naam wahi hone chahiye jo controller mein export kiye hain
const { createNotice, getAllNotices } = require('../controllers/noticeController');

// Routes
router.get('/', getAllNotices);
router.post('/', createNotice);

module.exports = router;