const express = require("express");
const router = express.Router();
// Yahan ensure karein ki file ka naam "studentController.js" hi hai
const { registerStudent, getAllStudents } = require("../controllers/studentController");

// Ab ye line error nahi degi kyunki upar function sahi se import ho gaye hain
router.post("/", registerStudent);
router.get("/", getAllStudents);

module.exports = router;