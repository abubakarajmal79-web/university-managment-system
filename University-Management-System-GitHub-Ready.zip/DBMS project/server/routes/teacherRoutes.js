const express = require("express");
const router = express.Router();
const { registerTeacher, getAllTeachers } = require("../controllers/teacherController");

router.route("/")
    .post(registerTeacher)
    .get(getAllTeachers);

module.exports = router;