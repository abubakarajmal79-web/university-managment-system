const express = require("express");
const router = express.Router();
const attendanceController = require("../controllers/attendanceController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Sub routes ko protect karne ke liye authentication require karein
router.use(protect);

// Routes Definition
router.get("/", attendanceController.getAllAttendance);
router.post("/", authorize("admin", "teacher"), attendanceController.markAttendance);

module.exports = router;