const express = require("express");
const router = express.Router();
const eventController = require("../controllers/eventController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public routes
router.get("/", eventController.getAllEvents);

// Protected routes (Admin access only)
router.post("/", protect, authorize("admin"), eventController.createEvent);
router.delete("/:id", protect, authorize("admin"), eventController.deleteEvent);

module.exports = router;