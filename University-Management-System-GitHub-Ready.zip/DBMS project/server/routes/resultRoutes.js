const express = require('express');
const router = express.Router();
// Check karein ki ye import sahi hai aur deleteResult variable exist karta hai
const { createResult, getAllResults, deleteResult } = require('../controllers/resultController');

router.get('/', getAllResults);
router.post('/', createResult);
router.delete('/:id', deleteResult); // Ensure deleteResult is imported properly

module.exports = router;