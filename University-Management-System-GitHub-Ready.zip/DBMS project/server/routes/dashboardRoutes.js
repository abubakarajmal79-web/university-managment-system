const express = require("express");
const router = express.Router();

const { getDashboardStats } = require("../controllers/dashboardController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Sirf logged in admin hi statistics dekh sake
router.get("/stats", protect, authorize("admin"), getDashboardStats);

module.exports = router;