const mysql = require("mysql2");

console.log("HOST =", process.env.DB_HOST);
console.log("USER =", process.env.DB_USER);
console.log("PASS =", process.env.DB_PASSWORD);
console.log("DB =", process.env.DB_NAME);

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10
});

db.getConnection((err, connection) => {

    if (err) {
        console.log(err);
        return;
    }

    console.log("✅ MySQL Connected");

    connection.release();

});

module.exports = db.promise();