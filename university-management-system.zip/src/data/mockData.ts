import { Student, Faculty, Course, AttendanceSession, GradeEntry, FeeInvoice, Announcement, Department } from '../types';

export const DEPARTMENTS: Department[] = [
  'Computer Science & AI',
  'Mechanical Engineering',
  'Business & Finance',
  'Bio-Medical Sciences',
  'School of Law',
  'Humanities & Design'
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 's1',
    studentId: 'STU-2024-001',
    name: 'Marcus Alexander Chen',
    email: 'm.chen@apex.edu',
    department: 'Computer Science & AI',
    semester: 5,
    year: 3,
    gpa: 3.88,
    cgpa: 3.82,
    status: 'Active',
    enrollmentDate: '2023-09-01',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 234-5678',
    advisor: 'Dr. Eleanor Vance',
    creditsCompleted: 78,
    enrolledCourseCodes: ['CS-301', 'CS-340', 'CS-410', 'MATH-220']
  },
  {
    id: 's2',
    studentId: 'STU-2024-002',
    name: 'Sophia Isabella Martinez',
    email: 's.martinez@apex.edu',
    department: 'Bio-Medical Sciences',
    semester: 3,
    year: 2,
    gpa: 3.94,
    cgpa: 3.91,
    status: 'Active',
    enrollmentDate: '2024-09-01',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 345-6789',
    advisor: 'Dr. Tariq Al-Mansoor',
    creditsCompleted: 44,
    enrolledCourseCodes: ['BIO-201', 'CHEM-102', 'MATH-220']
  },
  {
    id: 's3',
    studentId: 'STU-2024-003',
    name: 'David O\'Connor',
    email: 'd.oconnor@apex.edu',
    department: 'Mechanical Engineering',
    semester: 7,
    year: 4,
    gpa: 3.45,
    cgpa: 3.52,
    status: 'Active',
    enrollmentDate: '2022-09-01',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 456-7890',
    advisor: 'Prof. Robert Sterling',
    creditsCompleted: 110,
    enrolledCourseCodes: ['ME-401', 'ME-405', 'MATH-220']
  },
  {
    id: 's4',
    studentId: 'STU-2024-004',
    name: 'Amina Fatima Zahra',
    email: 'a.zahra@apex.edu',
    department: 'Business & Finance',
    semester: 5,
    year: 3,
    gpa: 3.72,
    cgpa: 3.68,
    status: 'Active',
    enrollmentDate: '2023-09-01',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 567-8901',
    advisor: 'Dr. Alistair Finch',
    creditsCompleted: 75,
    enrolledCourseCodes: ['BUS-301', 'BUS-315', 'CS-301']
  },
  {
    id: 's5',
    studentId: 'STU-2024-005',
    name: 'Liam James Gallagher',
    email: 'l.gallagher@apex.edu',
    department: 'School of Law',
    semester: 1,
    year: 1,
    gpa: 3.10,
    cgpa: 3.10,
    status: 'Probation',
    enrollmentDate: '2025-09-01',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 678-9012',
    advisor: 'Dean Victoria Kensington',
    creditsCompleted: 15,
    enrolledCourseCodes: ['LAW-101', 'LAW-105']
  },
  {
    id: 's6',
    studentId: 'STU-2024-006',
    name: 'Elena Rostova',
    email: 'e.rostova@apex.edu',
    department: 'Computer Science & AI',
    semester: 5,
    year: 3,
    gpa: 3.96,
    cgpa: 3.93,
    status: 'Active',
    enrollmentDate: '2023-09-01',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 789-0123',
    advisor: 'Dr. Eleanor Vance',
    creditsCompleted: 80,
    enrolledCourseCodes: ['CS-301', 'CS-340', 'CS-410']
  },
  {
    id: 's7',
    studentId: 'STU-2024-007',
    name: 'Kofi Kwabena Mensah',
    email: 'k.mensah@apex.edu',
    department: 'Humanities & Design',
    semester: 3,
    year: 2,
    gpa: 3.65,
    cgpa: 3.58,
    status: 'Active',
    enrollmentDate: '2024-09-01',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 890-1234',
    advisor: 'Prof. Helen Morland',
    creditsCompleted: 45,
    enrolledCourseCodes: ['HUM-201', 'CS-301']
  },
  {
    id: 's8',
    studentId: 'STU-2024-008',
    name: 'Hiroshi Tanaka',
    email: 'h.tanaka@apex.edu',
    department: 'Mechanical Engineering',
    semester: 5,
    year: 3,
    gpa: 3.30,
    cgpa: 3.42,
    status: 'On Leave',
    enrollmentDate: '2023-09-01',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 901-2345',
    advisor: 'Prof. Robert Sterling',
    creditsCompleted: 60,
    enrolledCourseCodes: ['ME-401']
  }
];

export const INITIAL_FACULTY: Faculty[] = [
  {
    id: 'f1',
    facultyId: 'FAC-101',
    name: 'Dr. Eleanor Vance',
    email: 'e.vance@apex.edu',
    department: 'Computer Science & AI',
    designation: 'Professor',
    office: 'Turing Hall, Room 402',
    phone: '+1 (555) 701-4401',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Deep Learning', 'Distributed Systems', 'Natural Language Processing'],
    courseCodes: ['CS-301', 'CS-410']
  },
  {
    id: 'f2',
    facultyId: 'FAC-102',
    name: 'Prof. Robert Sterling',
    email: 'r.sterling@apex.edu',
    department: 'Mechanical Engineering',
    designation: 'Department Dean',
    office: 'Edison Complex, Suite 100',
    phone: '+1 (555) 701-4402',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Fluid Dynamics', 'Robotic Kinematics', 'Advanced Materials'],
    courseCodes: ['ME-401', 'ME-405']
  },
  {
    id: 'f3',
    facultyId: 'FAC-103',
    name: 'Dr. Tariq Al-Mansoor',
    email: 't.almansoor@apex.edu',
    department: 'Bio-Medical Sciences',
    designation: 'Associate Professor',
    office: 'Franklin Medical Wing, 215',
    phone: '+1 (555) 701-4403',
    avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Molecular Genetics', 'CRISPR Therapeutics', 'Bio-Informatics'],
    courseCodes: ['BIO-201', 'CHEM-102']
  },
  {
    id: 'f4',
    facultyId: 'FAC-104',
    name: 'Dr. Alistair Finch',
    email: 'a.finch@apex.edu',
    department: 'Business & Finance',
    designation: 'Associate Professor',
    office: 'Smith Economics Tower, 508',
    phone: '+1 (555) 701-4404',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Quantitative Finance', 'Corporate Valuation', 'Macroeconomics'],
    courseCodes: ['BUS-301', 'BUS-315']
  },
  {
    id: 'f5',
    facultyId: 'FAC-105',
    name: 'Dean Victoria Kensington',
    email: 'v.kensington@apex.edu',
    department: 'School of Law',
    designation: 'Department Dean',
    office: 'Justice Hall, Chambers 3A',
    phone: '+1 (555) 701-4405',
    avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Constitutional Law', 'International Arbitration', 'Tech Ethics'],
    courseCodes: ['LAW-101', 'LAW-105']
  },
  {
    id: 'f6',
    facultyId: 'FAC-106',
    name: 'Prof. Marcus Holt',
    email: 'm.holt@apex.edu',
    department: 'Computer Science & AI',
    designation: 'Assistant Professor',
    office: 'Turing Hall, Room 318',
    phone: '+1 (555) 701-4406',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Database Architectures', 'Cloud Infrastructure', 'Cybersecurity'],
    courseCodes: ['CS-340', 'MATH-220']
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'c1',
    code: 'CS-301',
    title: 'Advanced Data Structures & Algorithms',
    department: 'Computer Science & AI',
    credits: 4,
    instructorId: 'f1',
    instructorName: 'Dr. Eleanor Vance',
    semester: 5,
    schedule: [
      { day: 'Mon', time: '09:00 - 10:30', room: 'Lecture Hall A-101' },
      { day: 'Wed', time: '09:00 - 10:30', room: 'Lecture Hall A-101' },
      { day: 'Fri', time: '14:00 - 16:00', room: 'CS Lab 3' }
    ],
    capacity: 60,
    enrolledCount: 48,
    syllabus: 'Graph algorithms, dynamic programming, amortization, NP-completeness, and balanced tree implementations in modern systems.',
    prerequisites: ['CS-201 Data Structures', 'MATH-102 Discrete Mathematics']
  },
  {
    id: 'c2',
    code: 'CS-340',
    title: 'Distributed Cloud Architectures',
    department: 'Computer Science & AI',
    credits: 3,
    instructorId: 'f6',
    instructorName: 'Prof. Marcus Holt',
    semester: 5,
    schedule: [
      { day: 'Tue', time: '11:00 - 12:30', room: 'Turing Hall 204' },
      { day: 'Thu', time: '11:00 - 12:30', room: 'Turing Hall 204' }
    ],
    capacity: 45,
    enrolledCount: 39,
    syllabus: 'Consensus protocols, Raft, Paxos, microservices patterns, serverless paradigms, and distributed data store guarantees.',
    prerequisites: ['CS-301']
  },
  {
    id: 'c3',
    code: 'CS-410',
    title: 'Neural Networks & Deep Learning',
    department: 'Computer Science & AI',
    credits: 4,
    instructorId: 'f1',
    instructorName: 'Dr. Eleanor Vance',
    semester: 7,
    schedule: [
      { day: 'Mon', time: '14:00 - 15:30', room: 'AI Computing Hub' },
      { day: 'Wed', time: '14:00 - 15:30', room: 'AI Computing Hub' }
    ],
    capacity: 40,
    enrolledCount: 35,
    syllabus: 'Feedforward networks, CNNs, Transformers, attention mechanisms, reinforcement learning, and PyTorch production deployments.',
    prerequisites: ['CS-301', 'MATH-220']
  },
  {
    id: 'c4',
    code: 'ME-401',
    title: 'Robotics Kinematics & Autonomous Control',
    department: 'Mechanical Engineering',
    credits: 4,
    instructorId: 'f2',
    instructorName: 'Prof. Robert Sterling',
    semester: 7,
    schedule: [
      { day: 'Tue', time: '09:00 - 10:30', room: 'Robotics Workshop B' },
      { day: 'Thu', time: '09:00 - 10:30', room: 'Robotics Workshop B' }
    ],
    capacity: 35,
    enrolledCount: 30,
    syllabus: 'Forward and inverse kinematics, Denavit-Hartenberg matrices, trajectory generation, and PID sensory feedback loops.',
    prerequisites: ['ME-301 Dynamics', 'MATH-220']
  },
  {
    id: 'c5',
    code: 'BIO-201',
    title: 'Genomics & Molecular Biotechnology',
    department: 'Bio-Medical Sciences',
    credits: 4,
    instructorId: 'f3',
    instructorName: 'Dr. Tariq Al-Mansoor',
    semester: 3,
    schedule: [
      { day: 'Mon', time: '10:45 - 12:15', room: 'Bio-Science Wing 105' },
      { day: 'Wed', time: '10:45 - 12:15', room: 'Bio-Science Wing 105' }
    ],
    capacity: 50,
    enrolledCount: 42,
    syllabus: 'Next-generation DNA sequencing, recombinant DNA, CRISPR-Cas9 genome editing, and bioinformatics sequence alignment.',
    prerequisites: ['BIO-101 Cellular Biology']
  },
  {
    id: 'c6',
    code: 'BUS-301',
    title: 'Corporate Finance & Investment Analysis',
    department: 'Business & Finance',
    credits: 3,
    instructorId: 'f4',
    instructorName: 'Dr. Alistair Finch',
    semester: 5,
    schedule: [
      { day: 'Tue', time: '14:00 - 15:30', room: 'Business Amphitheater' },
      { day: 'Thu', time: '14:00 - 15:30', room: 'Business Amphitheater' }
    ],
    capacity: 70,
    enrolledCount: 65,
    syllabus: 'Discounted cash flow, CAPM, option pricing, capital structure optimization, mergers & acquisitions, and private equity valuation.',
    prerequisites: ['BUS-201 Financial Accounting']
  },
  {
    id: 'c7',
    code: 'LAW-101',
    title: 'Constitutional Jurisprudence & Rights',
    department: 'School of Law',
    credits: 3,
    instructorId: 'f5',
    instructorName: 'Dean Victoria Kensington',
    semester: 1,
    schedule: [
      { day: 'Mon', time: '16:00 - 17:30', room: 'Moot Court Chamber' },
      { day: 'Wed', time: '16:00 - 17:30', room: 'Moot Court Chamber' }
    ],
    capacity: 80,
    enrolledCount: 76,
    syllabus: 'Separation of powers, judicial review mechanisms, due process doctrine, and comparative international constitutional frameworks.',
    prerequisites: ['None']
  },
  {
    id: 'c8',
    code: 'MATH-220',
    title: 'Linear Algebra & Multivariable Calculus',
    department: 'Computer Science & AI',
    credits: 4,
    instructorId: 'f6',
    instructorName: 'Prof. Marcus Holt',
    semester: 3,
    schedule: [
      { day: 'Wed', time: '11:00 - 12:30', room: 'Science Center 302' },
      { day: 'Fri', time: '11:00 - 12:30', room: 'Science Center 302' }
    ],
    capacity: 100,
    enrolledCount: 94,
    syllabus: 'Vector spaces, eigenvalues, singular value decomposition, gradient descent mechanics, and multi-dimensional integration.',
    prerequisites: ['MATH-101 Single Variable Calculus']
  }
];

export const INITIAL_ATTENDANCE: AttendanceSession[] = [
  {
    id: 'att-1',
    courseCode: 'CS-301',
    date: '2026-09-11',
    records: {
      'STU-2024-001': 'present',
      'STU-2024-004': 'present',
      'STU-2024-006': 'present',
      'STU-2024-007': 'late'
    }
  },
  {
    id: 'att-2',
    courseCode: 'CS-301',
    date: '2026-09-09',
    records: {
      'STU-2024-001': 'present',
      'STU-2024-004': 'present',
      'STU-2024-006': 'present',
      'STU-2024-007': 'present'
    }
  },
  {
    id: 'att-3',
    courseCode: 'BIO-201',
    date: '2026-09-10',
    records: {
      'STU-2024-002': 'present'
    }
  },
  {
    id: 'att-4',
    courseCode: 'ME-401',
    date: '2026-09-10',
    records: {
      'STU-2024-003': 'present',
      'STU-2024-008': 'absent'
    }
  }
];

export const INITIAL_GRADES: GradeEntry[] = [
  {
    id: 'g-1',
    studentId: 'STU-2024-001',
    studentName: 'Marcus Alexander Chen',
    courseCode: 'CS-301',
    semester: 5,
    assignmentsScore: 19.5,
    midtermScore: 28.0,
    finalExamScore: 47.0,
    totalScore: 94.5,
    letterGrade: 'A',
    gradePoint: 4.0,
    status: 'Published'
  },
  {
    id: 'g-2',
    studentId: 'STU-2024-006',
    studentName: 'Elena Rostova',
    courseCode: 'CS-301',
    semester: 5,
    assignmentsScore: 20.0,
    midtermScore: 29.5,
    finalExamScore: 48.5,
    totalScore: 98.0,
    letterGrade: 'A+',
    gradePoint: 4.0,
    status: 'Published'
  },
  {
    id: 'g-3',
    studentId: 'STU-2024-004',
    studentName: 'Amina Fatima Zahra',
    courseCode: 'CS-301',
    semester: 5,
    assignmentsScore: 17.5,
    midtermScore: 25.0,
    finalExamScore: 42.0,
    totalScore: 84.5,
    letterGrade: 'B+',
    gradePoint: 3.3,
    status: 'Published'
  },
  {
    id: 'g-4',
    studentId: 'STU-2024-007',
    studentName: 'Kofi Kwabena Mensah',
    courseCode: 'CS-301',
    semester: 3,
    assignmentsScore: 16.0,
    midtermScore: 23.5,
    finalExamScore: 39.0,
    totalScore: 78.5,
    letterGrade: 'B',
    gradePoint: 3.0,
    status: 'Draft'
  },
  {
    id: 'g-5',
    studentId: 'STU-2024-002',
    studentName: 'Sophia Isabella Martinez',
    courseCode: 'BIO-201',
    semester: 3,
    assignmentsScore: 19.8,
    midtermScore: 29.0,
    finalExamScore: 48.0,
    totalScore: 96.8,
    letterGrade: 'A+',
    gradePoint: 4.0,
    status: 'Published'
  },
  {
    id: 'g-6',
    studentId: 'STU-2024-003',
    studentName: 'David O\'Connor',
    courseCode: 'ME-401',
    semester: 7,
    assignmentsScore: 16.5,
    midtermScore: 24.0,
    finalExamScore: 41.5,
    totalScore: 82.0,
    letterGrade: 'B+',
    gradePoint: 3.3,
    status: 'Published'
  },
  {
    id: 'g-7',
    studentId: 'STU-2024-001',
    studentName: 'Marcus Alexander Chen',
    courseCode: 'CS-340',
    semester: 5,
    assignmentsScore: 18.5,
    midtermScore: 27.0,
    finalExamScore: 44.0,
    totalScore: 89.5,
    letterGrade: 'A-',
    gradePoint: 3.7,
    status: 'Published'
  }
];

export const INITIAL_FEES: FeeInvoice[] = [
  {
    id: 'fee-1',
    invoiceNumber: 'INV-2026-F-001',
    studentId: 'STU-2024-001',
    studentName: 'Marcus Alexander Chen',
    term: 'Fall Semester 2026',
    tuitionFee: 4800,
    labFee: 650,
    libraryFacilityFee: 250,
    totalAmount: 5700,
    paidAmount: 5700,
    dueDate: '2026-10-15',
    status: 'Paid',
    paidDate: '2026-09-02',
    paymentMethod: 'Electronic Bank Wire'
  },
  {
    id: 'fee-2',
    invoiceNumber: 'INV-2026-F-002',
    studentId: 'STU-2024-002',
    studentName: 'Sophia Isabella Martinez',
    term: 'Fall Semester 2026',
    tuitionFee: 5100,
    labFee: 850,
    libraryFacilityFee: 250,
    totalAmount: 6200,
    paidAmount: 6200,
    dueDate: '2026-10-15',
    status: 'Paid',
    paidDate: '2026-09-05',
    paymentMethod: 'Academic Merit Scholarship'
  },
  {
    id: 'fee-3',
    invoiceNumber: 'INV-2026-F-003',
    studentId: 'STU-2024-003',
    studentName: 'David O\'Connor',
    term: 'Fall Semester 2026',
    tuitionFee: 4800,
    labFee: 600,
    libraryFacilityFee: 250,
    totalAmount: 5650,
    paidAmount: 2500,
    dueDate: '2026-09-25',
    status: 'Pending',
    paymentMethod: 'Installment Plan'
  },
  {
    id: 'fee-4',
    invoiceNumber: 'INV-2026-F-004',
    studentId: 'STU-2024-004',
    studentName: 'Amina Fatima Zahra',
    term: 'Fall Semester 2026',
    tuitionFee: 4500,
    labFee: 300,
    libraryFacilityFee: 250,
    totalAmount: 5050,
    paidAmount: 5050,
    dueDate: '2026-10-15',
    status: 'Paid',
    paidDate: '2026-09-08',
    paymentMethod: 'Visa Card'
  },
  {
    id: 'fee-5',
    invoiceNumber: 'INV-2026-F-005',
    studentId: 'STU-2024-005',
    studentName: 'Liam James Gallagher',
    term: 'Fall Semester 2026',
    tuitionFee: 5200,
    labFee: 150,
    libraryFacilityFee: 250,
    totalAmount: 5600,
    paidAmount: 0,
    dueDate: '2026-09-10',
    status: 'Overdue'
  },
  {
    id: 'fee-6',
    invoiceNumber: 'INV-2026-F-006',
    studentId: 'STU-2024-006',
    studentName: 'Elena Rostova',
    term: 'Fall Semester 2026',
    tuitionFee: 4800,
    labFee: 650,
    libraryFacilityFee: 250,
    totalAmount: 5700,
    paidAmount: 5700,
    dueDate: '2026-10-15',
    status: 'Paid',
    paidDate: '2026-09-01',
    paymentMethod: 'Corporate Sponsorship'
  },
  {
    id: 'fee-7',
    invoiceNumber: 'INV-2026-F-007',
    studentId: 'STU-2024-007',
    studentName: 'Kofi Kwabena Mensah',
    term: 'Fall Semester 2026',
    tuitionFee: 4300,
    labFee: 350,
    libraryFacilityFee: 250,
    totalAmount: 4900,
    paidAmount: 2000,
    dueDate: '2026-09-30',
    status: 'Pending'
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Fall 2026 Midterm Examination Timetable Released',
    content: 'The Office of the University Registrar has officially published the Midterm Examination schedule for all undergraduate and graduate courses. Please inspect exam hall assignments and conflict resolution procedures before October 1st.',
    author: 'Registrar Academic Affairs',
    authorRole: 'Administration',
    date: '2026-09-12',
    category: 'Examination',
    priority: 'Urgent'
  },
  {
    id: 'ann-2',
    title: 'Annual Research & Innovation Grant Symposium 2026',
    content: 'Undergraduate and faculty research abstracts are now open for submission. Winning projects in AI, Clean Energy, and Bio-tech will receive up to $25,000 in seed endowment funding from the University Innovation Board.',
    author: 'Dr. Eleanor Vance',
    authorRole: 'Dean of Research',
    date: '2026-09-10',
    category: 'Academic',
    priority: 'Standard'
  },
  {
    id: 'ann-3',
    title: 'Library System Scheduled Maintenance & Digital Access Upgrade',
    content: 'The centralized campus digital repository and JSTOR gateway will undergo a cloud migration this Saturday from 01:00 to 05:00 AM UTC. Physical library study carrels remain accessible 24/7 with RFID card badges.',
    author: 'Campus IT Operations',
    authorRole: 'Infrastructure',
    date: '2026-09-08',
    category: 'Administrative',
    priority: 'General'
  },
  {
    id: 'ann-4',
    title: 'Tuition Installment Second Window Deadline Notice',
    content: 'Students enrolled in the flexible semester installment plan are reminded that the second payment installment must be cleared by September 30, 2026 to prevent academic portal hold restrictions.',
    author: 'Bursar & Finance Office',
    authorRole: 'Finance',
    date: '2026-09-05',
    category: 'Administrative',
    priority: 'Standard'
  }
];

export function calculateGrade(total: number): { letter: string; point: number } {
  if (total >= 93) return { letter: 'A', point: 4.0 };
  if (total >= 90) return { letter: 'A-', point: 3.7 };
  if (total >= 87) return { letter: 'B+', point: 3.3 };
  if (total >= 83) return { letter: 'B', point: 3.0 };
  if (total >= 80) return { letter: 'B-', point: 2.7 };
  if (total >= 77) return { letter: 'C+', point: 2.3 };
  if (total >= 73) return { letter: 'C', point: 2.0 };
  if (total >= 70) return { letter: 'C-', point: 1.7 };
  if (total >= 60) return { letter: 'D', point: 1.0 };
  return { letter: 'F', point: 0.0 };
}
