export type UserRole = 'admin' | 'faculty' | 'student';

export type Department = 
  | 'Computer Science & AI'
  | 'Mechanical Engineering'
  | 'Business & Finance'
  | 'Bio-Medical Sciences'
  | 'School of Law'
  | 'Humanities & Design';

export type StudentStatus = 'Active' | 'On Leave' | 'Probation' | 'Graduated';

export interface Student {
  id: string;
  studentId: string;
  name: string;
  email: string;
  department: Department;
  semester: number;
  year: number;
  gpa: number;
  cgpa: number;
  status: StudentStatus;
  enrollmentDate: string;
  avatar: string;
  phone: string;
  advisor: string;
  creditsCompleted: number;
  enrolledCourseCodes: string[];
}

export interface Faculty {
  id: string;
  facultyId: string;
  name: string;
  email: string;
  department: Department;
  designation: 'Department Dean' | 'Professor' | 'Associate Professor' | 'Assistant Professor' | 'Lecturer';
  office: string;
  phone: string;
  avatar: string;
  specializedFields: string[];
  courseCodes: string[];
}

export interface CourseScheduleSlot {
  day: 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri';
  time: string;
  room: string;
}

export interface Course {
  id: string;
  code: string;
  title: string;
  department: Department;
  credits: number;
  instructorId: string;
  instructorName: string;
  semester: number;
  schedule: CourseScheduleSlot[];
  capacity: number;
  enrolledCount: number;
  syllabus: string;
  prerequisites: string[];
}

export type AttendanceStatusType = 'present' | 'absent' | 'late' | 'excused';

export interface StudentAttendanceEntry {
  studentId: string;
  status: AttendanceStatusType;
  remarks?: string;
}

export interface AttendanceSession {
  id: string;
  courseCode: string;
  date: string;
  records: Record<string, AttendanceStatusType>; // studentId -> status
}

export interface GradeEntry {
  id: string;
  studentId: string;
  studentName: string;
  courseCode: string;
  semester: number;
  assignmentsScore: number; // Max 20
  midtermScore: number;     // Max 30
  finalExamScore: number;   // Max 50
  totalScore: number;       // 0-100
  letterGrade: string;      // A+, A, B, etc.
  gradePoint: number;       // 4.0 scale
  status: 'Draft' | 'Published';
}

export type FeeStatusType = 'Paid' | 'Pending' | 'Overdue';

export interface FeeInvoice {
  id: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  term: string;
  tuitionFee: number;
  labFee: number;
  libraryFacilityFee: number;
  totalAmount: number;
  paidAmount: number;
  dueDate: string;
  status: FeeStatusType;
  paidDate?: string;
  paymentMethod?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  authorRole: string;
  date: string;
  category: 'Academic' | 'Examination' | 'Administrative' | 'Events';
  priority: 'Urgent' | 'Standard' | 'General';
}
