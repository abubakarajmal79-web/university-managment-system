import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  UserRole, 
  Student, 
  Faculty, 
  Course, 
  AttendanceSession, 
  GradeEntry, 
  FeeInvoice, 
  Announcement,
  Department,
  AttendanceStatusType
} from '../types';
import { 
  INITIAL_STUDENTS, 
  INITIAL_FACULTY, 
  INITIAL_COURSES, 
  INITIAL_ATTENDANCE, 
  INITIAL_GRADES, 
  INITIAL_FEES, 
  INITIAL_ANNOUNCEMENTS,
  calculateGrade
} from '../data/mockData';

interface UniversityContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  activeStudentId: string;
  setActiveStudentId: (id: string) => void;
  activeFacultyId: string;
  setActiveFacultyId: (id: string) => void;
  
  students: Student[];
  faculty: Faculty[];
  courses: Course[];
  attendance: AttendanceSession[];
  grades: GradeEntry[];
  fees: FeeInvoice[];
  announcements: Announcement[];

  // Mutations
  addStudent: (student: Omit<Student, 'id'>) => void;
  updateStudent: (id: string, data: Partial<Student>) => void;
  deleteStudent: (id: string) => void;

  addFaculty: (fac: Omit<Faculty, 'id'>) => void;
  updateFaculty: (id: string, data: Partial<Faculty>) => void;
  deleteFaculty: (id: string) => void;

  addCourse: (course: Omit<Course, 'id'>) => void;
  updateCourse: (id: string, data: Partial<Course>) => void;
  deleteCourse: (id: string) => void;

  saveAttendanceSession: (courseCode: string, date: string, records: Record<string, AttendanceStatusType>) => void;
  getAttendanceForStudent: (studentId: string, courseCode?: string) => { total: number; present: number; rate: number };

  saveGradeEntry: (grade: Omit<GradeEntry, 'id' | 'totalScore' | 'letterGrade' | 'gradePoint'>) => void;
  updateGradeEntry: (id: string, data: Partial<GradeEntry>) => void;

  payFeeInvoice: (invoiceId: string, amount: number, method: string) => void;
  addAnnouncement: (announcement: Omit<Announcement, 'id' | 'date'>) => void;
  deleteAnnouncement: (id: string) => void;

  resetToDemoData: () => void;

  // Key metrics
  metrics: {
    totalStudents: number;
    activeStudents: number;
    totalFaculty: number;
    totalCourses: number;
    avgGpa: number;
    attendanceRate: number;
    totalFeesCollected: number;
    totalFeesPending: number;
  };
}

const UniversityContext = createContext<UniversityContextType | undefined>(undefined);

const STORAGE_KEYS = {
  ROLE: 'ums_role_v1',
  STUDENT_ID: 'ums_active_student_v1',
  FACULTY_ID: 'ums_active_faculty_v1',
  STUDENTS: 'ums_students_v1',
  FACULTY: 'ums_faculty_v1',
  COURSES: 'ums_courses_v1',
  ATTENDANCE: 'ums_attendance_v1',
  GRADES: 'ums_grades_v1',
  FEES: 'ums_fees_v1',
  ANNOUNCEMENTS: 'ums_announcements_v1'
};

export const UniversityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole>(() => {
    return (localStorage.getItem(STORAGE_KEYS.ROLE) as UserRole) || 'admin';
  });

  const [activeStudentId, setActiveStudentIdState] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.STUDENT_ID) || 'STU-2024-001';
  });

  const [activeFacultyId, setActiveFacultyIdState] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.FACULTY_ID) || 'f1';
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [faculty, setFaculty] = useState<Faculty[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FACULTY);
    return saved ? JSON.parse(saved) : INITIAL_FACULTY;
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COURSES);
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [attendance, setAttendance] = useState<AttendanceSession[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });

  const [grades, setGrades] = useState<GradeEntry[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GRADES);
    return saved ? JSON.parse(saved) : INITIAL_GRADES;
  });

  const [fees, setFees] = useState<FeeInvoice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FEES);
    return saved ? JSON.parse(saved) : INITIAL_FEES;
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS);
    return saved ? JSON.parse(saved) : INITIAL_ANNOUNCEMENTS;
  });

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENT_ID, activeStudentId);
  }, [activeStudentId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FACULTY_ID, activeFacultyId);
  }, [activeFacultyId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FACULTY, JSON.stringify(faculty));
  }, [faculty]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GRADES, JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FEES, JSON.stringify(fees));
  }, [fees]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));
  }, [announcements]);

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
  };

  const setActiveStudentId = (id: string) => {
    setActiveStudentIdState(id);
  };

  const setActiveFacultyId = (id: string) => {
    setActiveFacultyIdState(id);
  };

  const addStudent = (newStudentData: Omit<Student, 'id'>) => {
    const newStudent: Student = {
      ...newStudentData,
      id: 's_' + Date.now()
    };
    setStudents(prev => [newStudent, ...prev]);
  };

  const updateStudent = (id: string, data: Partial<Student>) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...data } : s));
  };

  const deleteStudent = (id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
  };

  const addFaculty = (newFacultyData: Omit<Faculty, 'id'>) => {
    const newFac: Faculty = {
      ...newFacultyData,
      id: 'f_' + Date.now()
    };
    setFaculty(prev => [...prev, newFac]);
  };

  const updateFaculty = (id: string, data: Partial<Faculty>) => {
    setFaculty(prev => prev.map(f => f.id === id ? { ...f, ...data } : f));
  };

  const deleteFaculty = (id: string) => {
    setFaculty(prev => prev.filter(f => f.id !== id));
  };

  const addCourse = (newCourseData: Omit<Course, 'id'>) => {
    const newC: Course = {
      ...newCourseData,
      id: 'c_' + Date.now()
    };
    setCourses(prev => [...prev, newC]);
  };

  const updateCourse = (id: string, data: Partial<Course>) => {
    setCourses(prev => prev.map(c => c.id === id ? { ...c, ...data } : c));
  };

  const deleteCourse = (id: string) => {
    setCourses(prev => prev.filter(c => c.id !== id));
  };

  const saveAttendanceSession = (courseCode: string, date: string, records: Record<string, AttendanceStatusType>) => {
    setAttendance(prev => {
      const existingIdx = prev.findIndex(a => a.courseCode === courseCode && a.date === date);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          records: { ...updated[existingIdx].records, ...records }
        };
        return updated;
      }
      return [
        {
          id: 'att_' + Date.now(),
          courseCode,
          date,
          records
        },
        ...prev
      ];
    });
  };

  const getAttendanceForStudent = (studentId: string, courseCode?: string) => {
    let total = 0;
    let present = 0;

    attendance.forEach(session => {
      if (courseCode && session.courseCode !== courseCode) return;
      const status = session.records[studentId];
      if (status) {
        total++;
        if (status === 'present' || status === 'excused') {
          present++;
        } else if (status === 'late') {
          present += 0.8;
        }
      }
    });

    const rate = total > 0 ? Math.round((present / total) * 100) : 100;
    return { total, present: Math.round(present), rate };
  };

  const saveGradeEntry = (gradeData: Omit<GradeEntry, 'id' | 'totalScore' | 'letterGrade' | 'gradePoint'>) => {
    const total = gradeData.assignmentsScore + gradeData.midtermScore + gradeData.finalExamScore;
    const { letter, point } = calculateGrade(total);

    const newGrade: GradeEntry = {
      ...gradeData,
      id: 'g_' + Date.now(),
      totalScore: Number(total.toFixed(1)),
      letterGrade: letter,
      gradePoint: point
    };

    setGrades(prev => {
      const existingIdx = prev.findIndex(g => g.studentId === gradeData.studentId && g.courseCode === gradeData.courseCode);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx] = newGrade;
        return updated;
      }
      return [newGrade, ...prev];
    });
  };

  const updateGradeEntry = (id: string, data: Partial<GradeEntry>) => {
    setGrades(prev => prev.map(g => {
      if (g.id !== id) return g;
      const updated = { ...g, ...data };
      const total = (updated.assignmentsScore ?? g.assignmentsScore) + 
                    (updated.midtermScore ?? g.midtermScore) + 
                    (updated.finalExamScore ?? g.finalExamScore);
      const { letter, point } = calculateGrade(total);
      return {
        ...updated,
        totalScore: Number(total.toFixed(1)),
        letterGrade: letter,
        gradePoint: point
      };
    }));
  };

  const payFeeInvoice = (invoiceId: string, amount: number, method: string) => {
    const today = new Date().toISOString().split('T')[0];
    setFees(prev => prev.map(inv => {
      if (inv.id !== invoiceId) return inv;
      const newPaid = inv.paidAmount + amount;
      const isFullyPaid = newPaid >= inv.totalAmount;
      return {
        ...inv,
        paidAmount: newPaid,
        status: isFullyPaid ? 'Paid' : 'Pending',
        paidDate: today,
        paymentMethod: method
      };
    }));
  };

  const addAnnouncement = (annData: Omit<Announcement, 'id' | 'date'>) => {
    const today = new Date().toISOString().split('T')[0];
    const newAnn: Announcement = {
      ...annData,
      id: 'ann_' + Date.now(),
      date: today
    };
    setAnnouncements(prev => [newAnn, ...prev]);
  };

  const deleteAnnouncement = (id: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
  };

  const resetToDemoData = () => {
    setStudents(INITIAL_STUDENTS);
    setFaculty(INITIAL_FACULTY);
    setCourses(INITIAL_COURSES);
    setAttendance(INITIAL_ATTENDANCE);
    setGrades(INITIAL_GRADES);
    setFees(INITIAL_FEES);
    setAnnouncements(INITIAL_ANNOUNCEMENTS);
    setRoleState('admin');
    setActiveStudentIdState('STU-2024-001');
    setActiveFacultyIdState('f1');
    localStorage.clear();
  };

  // Metrics computation
  const activeStudentsCount = students.filter(s => s.status === 'Active').length;
  const avgGpa = students.length > 0 
    ? Number((students.reduce((acc, s) => acc + s.cgpa, 0) / students.length).toFixed(2)) 
    : 0;

  let totalAttendanceChecks = 0;
  let presentAttendanceChecks = 0;
  attendance.forEach(session => {
    Object.values(session.records).forEach(status => {
      totalAttendanceChecks++;
      if (status === 'present' || status === 'excused') presentAttendanceChecks++;
      else if (status === 'late') presentAttendanceChecks += 0.8;
    });
  });

  const attendanceRate = totalAttendanceChecks > 0 
    ? Math.round((presentAttendanceChecks / totalAttendanceChecks) * 100) 
    : 94;

  const totalFeesCollected = fees.reduce((acc, f) => acc + f.paidAmount, 0);
  const totalFeesPending = fees.reduce((acc, f) => acc + (f.totalAmount - f.paidAmount), 0);

  return (
    <UniversityContext.Provider
      value={{
        role,
        setRole,
        activeStudentId,
        setActiveStudentId,
        activeFacultyId,
        setActiveFacultyId,
        students,
        faculty,
        courses,
        attendance,
        grades,
        fees,
        announcements,
        addStudent,
        updateStudent,
        deleteStudent,
        addFaculty,
        updateFaculty,
        deleteFaculty,
        addCourse,
        updateCourse,
        deleteCourse,
        saveAttendanceSession,
        getAttendanceForStudent,
        saveGradeEntry,
        updateGradeEntry,
        payFeeInvoice,
        addAnnouncement,
        deleteAnnouncement,
        resetToDemoData,
        metrics: {
          totalStudents: students.length,
          activeStudents: activeStudentsCount,
          totalFaculty: faculty.length,
          totalCourses: courses.length,
          avgGpa,
          attendanceRate,
          totalFeesCollected,
          totalFeesPending
        }
      }}
    >
      {children}
    </UniversityContext.Provider>
  );
};

export const useUniversity = () => {
  const context = useContext(UniversityContext);
  if (!context) {
    throw new Error('useUniversity must be used within a UniversityProvider');
  }
  return context;
};
