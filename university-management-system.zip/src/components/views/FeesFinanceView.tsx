import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { FeeInvoice, FeeStatusType } from '../../types';
import { 
  CreditCard, 
  Search, 
  DollarSign, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Receipt, 
  Printer, 
  X, 
  ShieldCheck,
  Building,
  GraduationCap
} from 'lucide-react';

export const FeesFinanceView: React.FC = () => {
  const { fees, payFeeInvoice, metrics, role, activeStudentId, students } = useUniversity();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedInvoiceForPay, setSelectedInvoiceForPay] = useState<FeeInvoice | null>(null);
  const [selectedReceiptInvoice, setSelectedReceiptInvoice] = useState<FeeInvoice | null>(null);

  // Payment Form State
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('Electronic Bank Wire');
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Filter invoices
  const filteredFees = fees.filter(inv => {
    const matchesSearch = 
      inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.studentId.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'All' || inv.status === statusFilter;

    // If role is student, only show their own invoices
    const matchesStudent = role === 'student' ? inv.studentId === activeStudentId : true;

    return matchesSearch && matchesStatus && matchesStudent;
  });

  const handleOpenPay = (inv: FeeInvoice) => {
    setSelectedInvoiceForPay(inv);
    setPaymentAmount(inv.totalAmount - inv.paidAmount);
  };

  const handleExecutePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoiceForPay) return;

    payFeeInvoice(selectedInvoiceForPay.id, paymentAmount, paymentMethod);
    setPaymentSuccess(true);
    setTimeout(() => {
      setPaymentSuccess(false);
      // Show receipt
      const updated = fees.find(f => f.id === selectedInvoiceForPay.id);
      setSelectedInvoiceForPay(null);
      if (updated) {
        setSelectedReceiptInvoice(updated);
      }
    }, 1200);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">University Bursar & Tuition Ledger</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Semester tuition assessments, lab facility surcharges, installment tracking, and verified cashier receipts.
          </p>
        </div>
      </div>

      {/* Financial KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block mb-1">Total Assessed</span>
          <span className="text-xl font-bold text-slate-900">
            ${(metrics.totalFeesCollected + metrics.totalFeesPending).toLocaleString()}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Fall Semester 2026</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block mb-1">Total Collected</span>
          <span className="text-xl font-bold text-emerald-600">
            ${metrics.totalFeesCollected.toLocaleString()}
          </span>
          <span className="text-[10px] text-emerald-600 block mt-0.5">
            {Math.round((metrics.totalFeesCollected / (metrics.totalFeesCollected + metrics.totalFeesPending)) * 100)}% realization
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block mb-1">Pending Receivables</span>
          <span className="text-xl font-bold text-amber-600">
            ${metrics.totalFeesPending.toLocaleString()}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Installment accounts</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block mb-1">Overdue Invoices</span>
          <span className="text-xl font-bold text-rose-600">
            {fees.filter(f => f.status === 'Overdue').length} Accounts
          </span>
          <span className="text-[10px] text-rose-500 block mt-0.5">Late penalty notices</span>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="fees-search-input"
            type="text"
            placeholder="Search by invoice number (e.g. INV-2026), student name, or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
          />
        </div>

        <div className="w-full md:w-56">
          <select
            id="fees-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="All">All Invoices</option>
            <option value="Paid">Paid in Full</option>
            <option value="Pending">Pending Installment</option>
            <option value="Overdue">Overdue Notice</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Term</th>
                <th className="py-3 px-4 text-right">Tuition</th>
                <th className="py-3 px-4 text-right">Facilities</th>
                <th className="py-3 px-4 text-right">Total Assessment</th>
                <th className="py-3 px-4 text-right">Paid</th>
                <th className="py-3 px-4 text-center">Due Date</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredFees.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-10 text-center text-slate-400">
                    No fee invoices match your search query.
                  </td>
                </tr>
              ) : (
                filteredFees.map(inv => {
                  const balance = inv.totalAmount - inv.paidAmount;
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/60 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {inv.invoiceNumber}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-800 block">{inv.studentName}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{inv.studentId}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {inv.term}
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-700">
                        ${inv.tuitionFee.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-500">
                        ${(inv.labFee + inv.libraryFacilityFee).toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                        ${inv.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-emerald-700">
                        ${inv.paidAmount.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-center text-slate-600 font-medium">
                        {inv.dueDate}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          inv.status === 'Paid'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : inv.status === 'Overdue'
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}>
                          {inv.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          {inv.status !== 'Paid' && (
                            <button
                              id={`pay-btn-${inv.invoiceNumber}`}
                              onClick={() => handleOpenPay(inv)}
                              className="px-2.5 py-1 bg-slate-900 text-white rounded text-xs font-semibold hover:bg-slate-800 transition"
                            >
                              Pay Now
                            </button>
                          )}
                          <button
                            id={`receipt-btn-${inv.invoiceNumber}`}
                            onClick={() => setSelectedReceiptInvoice(inv)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded transition"
                            title="View Official Cashier Receipt"
                          >
                            <Receipt className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Processing Modal */}
      {selectedInvoiceForPay && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h2 className="text-base font-bold text-slate-900">Process Fee Settlement</h2>
                <span className="text-xs text-slate-500">{selectedInvoiceForPay.invoiceNumber}</span>
              </div>
              <button 
                onClick={() => setSelectedInvoiceForPay(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {paymentSuccess ? (
              <div className="py-8 text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-900">Transaction Approved</h3>
                <p className="text-xs text-slate-500">Generating certified electronic cashier receipt...</p>
              </div>
            ) : (
              <form onSubmit={handleExecutePayment} className="mt-4 space-y-4 text-xs">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Student Name:</span>
                    <strong className="text-slate-800">{selectedInvoiceForPay.studentName}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Outstanding Balance:</span>
                    <strong className="text-rose-600 font-bold">
                      ${(selectedInvoiceForPay.totalAmount - selectedInvoiceForPay.paidAmount).toLocaleString()}
                    </strong>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Amount to Pay ($ USD)</label>
                  <input
                    type="number"
                    min={1}
                    max={selectedInvoiceForPay.totalAmount - selectedInvoiceForPay.paidAmount}
                    required
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-bold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="Electronic Bank Wire">Electronic Bank Wire (ACH/SWIFT)</option>
                    <option value="Visa / Mastercard">Debit / Credit Card (Stripe/Visa)</option>
                    <option value="Academic Merit Scholarship">Academic Merit Endowment Deduction</option>
                    <option value="Campus Cashier Counter">Campus Bursar Cash Desk</option>
                  </select>
                </div>

                <div className="pt-3 border-t border-slate-200 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setSelectedInvoiceForPay(null)}
                    className="px-4 py-2 border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition"
                  >
                    Confirm & Settle Payment
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

      {/* Certified Cashier Receipt Modal */}
      {selectedReceiptInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            
            {/* Receipt Header */}
            <div className="text-center pb-4 border-b border-dashed border-slate-300">
              <div className="flex items-center justify-center space-x-1.5 mb-1">
                <GraduationCap className="w-5 h-5 text-slate-900" />
                <h3 className="font-bold text-slate-900 tracking-tight text-sm">APEX STATE UNIVERSITY</h3>
              </div>
              <p className="text-[10px] text-slate-500 uppercase font-semibold">Official University Cashier Receipt</p>
              <p className="text-[10px] font-mono text-slate-400 mt-1">{selectedReceiptInvoice.invoiceNumber}</p>
            </div>

            {/* Receipt Body */}
            <div className="py-4 space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Receipt Date:</span>
                <span className="font-semibold text-slate-800">{selectedReceiptInvoice.paidDate || '2026-09-14'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Student Name:</span>
                <span className="font-bold text-slate-800">{selectedReceiptInvoice.studentName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Student ID:</span>
                <span className="font-mono text-slate-800">{selectedReceiptInvoice.studentId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Term:</span>
                <span className="text-slate-800">{selectedReceiptInvoice.term}</span>
              </div>
              
              <div className="my-3 py-2 border-y border-dashed border-slate-200 space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>Tuition Assessment</span>
                  <span>${selectedReceiptInvoice.tuitionFee.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Science / Tech Lab Surcharge</span>
                  <span>${selectedReceiptInvoice.labFee.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Library & Campus Facilities</span>
                  <span>${selectedReceiptInvoice.libraryFacilityFee.toLocaleString()}</span>
                </div>
              </div>

              <div className="flex justify-between font-bold text-sm text-slate-900">
                <span>Total Assessment:</span>
                <span>${selectedReceiptInvoice.totalAmount.toLocaleString()}</span>
              </div>

              <div className="flex justify-between font-bold text-xs text-emerald-700">
                <span>Total Amount Paid:</span>
                <span>${selectedReceiptInvoice.paidAmount.toLocaleString()}</span>
              </div>

              <div className="flex justify-between text-xs text-slate-600">
                <span>Remaining Balance:</span>
                <span className="font-semibold">
                  ${(selectedReceiptInvoice.totalAmount - selectedReceiptInvoice.paidAmount).toLocaleString()}
                </span>
              </div>

              {selectedReceiptInvoice.paymentMethod && (
                <div className="pt-2 text-[11px] text-slate-400">
                  Payment Method: <strong className="text-slate-600">{selectedReceiptInvoice.paymentMethod}</strong>
                </div>
              )}
            </div>

            {/* Stamp / Verification Footer */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-center mb-4">
              <span className="text-[10px] text-slate-400 block">Electronic Cashier Verification Code</span>
              <span className="font-mono text-xs font-bold text-slate-800">
                AUTH-APX-849204-VERIFIED
              </span>
            </div>

            {/* Actions */}
            <div className="flex space-x-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition flex items-center justify-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Receipt</span>
              </button>
              <button
                onClick={() => setSelectedReceiptInvoice(null)}
                className="flex-1 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
