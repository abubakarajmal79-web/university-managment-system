import React from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { 
  Users, 
  GraduationCap, 
  BookOpen, 
  CheckCircle, 
  DollarSign, 
  TrendingUp, 
  Clock, 
  AlertCircle,
  Megaphone,
  ArrowUpRight,
  Calendar,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid, 
  AreaChart, 
  Area 
} from 'recharts';

interface DashboardViewProps {
  setActiveTab: (tab: string) => void;
  onOpenAddStudent?: () => void;
  onOpenAddCourse?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab }) => {
  const { 
    role, 
    metrics, 
    students, 
    faculty, 
    courses, 
    announcements, 
    activeStudentId, 
    activeFacultyId,
    getAttendanceForStudent
  } = useUniversity();

  const activeStudent = students.find(s => s.studentId === activeStudentId) || students[0];
  const activeFacultyMember = faculty.find(f => f.id === activeFacultyId) || faculty[0];

  // Prepare chart data: Students per Department
  const deptCounts: Record<string, number> = {};
  students.forEach(s => {
    const shortName = s.department.replace('Computer Science & AI', 'CS & AI')
      .replace('Mechanical Engineering', 'Mech Eng')
      .replace('Business & Finance', 'Business')
      .replace('Bio-Medical Sciences', 'Bio-Med')
      .replace('School of Law', 'Law')
      .replace('Humanities & Design', 'Humanities');
    deptCounts[shortName] = (deptCounts[shortName] || 0) + 1;
  });

  const departmentData = Object.keys(deptCounts).map(dept => ({
    department: dept,
    students: deptCounts[dept]
  }));

  // Weekly attendance trend simulation data
  const attendanceTrendData = [
    { week: 'Week 1', rate: 96 },
    { week: 'Week 2', rate: 93 },
    { week: 'Week 3', rate: metrics.attendanceRate },
    { week: 'Week 4 (Proj)', rate: 95 },
  ];

  const studentAttendance = getAttendanceForStudent(activeStudent?.studentId);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
            <span>Apex University Portal</span>
            <span>•</span>
            <span className="text-amber-600">
              {role === 'admin' ? 'Administrative Operations' : role === 'faculty' ? 'Faculty Command' : 'Student Hub'}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            {role === 'admin' && 'University Institutional Dashboard'}
            {role === 'faculty' && `Welcome back, ${activeFacultyMember.name}`}
            {role === 'student' && `Welcome back, ${activeStudent.name}`}
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            {role === 'admin' && 'Monitor university KPIs, departmental enrollments, faculty workloads, fee collections, and urgent campus bulletins.'}
            {role === 'faculty' && `Department of ${activeFacultyMember.department}. You have ${activeFacultyMember.courseCodes.length} active courses scheduled this semester.`}
            {role === 'student' && `${activeStudent.department} • Semester ${activeStudent.semester} (Year ${activeStudent.year}) • Student ID: ${activeStudent.studentId}`}
          </p>
        </div>

        {/* Quick action shortcuts */}
        <div className="flex items-center gap-2">
          {role === 'admin' && (
            <>
              <button
                id="btn-dash-add-student"
                onClick={() => setActiveTab('students')}
                className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition shadow-xs flex items-center gap-1.5"
              >
                <Users className="w-3.5 h-3.5 text-amber-400" />
                <span>Manage Students</span>
              </button>
              <button
                id="btn-dash-attendance"
                onClick={() => setActiveTab('attendance')}
                className="px-3.5 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition flex items-center gap-1.5"
              >
                <CheckCircle className="w-3.5 h-3.5 text-slate-500" />
                <span>Mark Attendance</span>
              </button>
            </>
          )}

          {role === 'faculty' && (
            <>
              <button
                onClick={() => setActiveTab('attendance')}
                className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5"
              >
                <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>Take Attendance</span>
              </button>
              <button
                onClick={() => setActiveTab('gradebook')}
                className="px-3.5 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition"
              >
                Gradebook
              </button>
            </>
          )}

          {role === 'student' && (
            <>
              <button
                onClick={() => setActiveTab('courses')}
                className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>My Courses</span>
              </button>
              <button
                onClick={() => setActiveTab('fees')}
                className="px-3.5 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition"
              >
                Fee Invoices
              </button>
            </>
          )}
        </div>
      </div>

      {/* Primary KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Students */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 block mb-1">Enrolled Students</span>
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-bold text-slate-900">{metrics.totalStudents}</span>
              <span className="text-xs text-emerald-600 font-medium">100% active</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">Across 6 academic schools</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Card 2: Faculty Members */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 block mb-1">Academic Faculty</span>
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-bold text-slate-900">{metrics.totalFaculty}</span>
              <span className="text-xs text-slate-500 font-medium">Deans & Profs</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">1:8 Faculty-student ratio</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100">
            <GraduationCap className="w-5 h-5" />
          </div>
        </div>

        {/* Card 3: Attendance Rate */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 block mb-1">Campus Attendance</span>
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-bold text-slate-900">{metrics.attendanceRate}%</span>
              <span className="text-xs text-emerald-600 font-medium">+1.4% vs W2</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">Senate min threshold: 75%</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        {/* Card 4: Fee Collection / Student CGPA */}
        {role === 'student' ? (
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-500 block mb-1">Cumulative CGPA</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold text-slate-900">{activeStudent.cgpa.toFixed(2)}</span>
                <span className="text-xs text-amber-600 font-medium">/ 4.00</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">{activeStudent.creditsCompleted} Credits Earned</p>
            </div>
            <div className="w-11 h-11 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
        ) : (
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-500 block mb-1">Tuition Realized</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold text-slate-900">
                  ${(metrics.totalFeesCollected / 1000).toFixed(1)}k
                </span>
                <span className="text-xs text-slate-500 font-medium">
                  / ${( (metrics.totalFeesCollected + metrics.totalFeesPending) / 1000).toFixed(1)}k
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {Math.round((metrics.totalFeesCollected / (metrics.totalFeesCollected + metrics.totalFeesPending)) * 100)}% collected
              </p>
            </div>
            <div className="w-11 h-11 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
        )}

      </div>

      {/* Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Department Enrollment Distribution Chart */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Departmental Student Enrollment</h2>
              <p className="text-xs text-slate-500">Distribution of registered undergraduates across departments</p>
            </div>
            <button 
              onClick={() => setActiveTab('students')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>View Roster</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="department" 
                  tick={{ fontSize: 11, fill: '#64748b' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: '#64748b' }} 
                  axisLine={false} 
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                  cursor={{ fill: '#f8fafc' }}
                />
                <Bar dataKey="students" name="Students" fill="#334155" radius={[4, 4, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Weekly Attendance Stability Trend */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Attendance Stability</h2>
                <p className="text-xs text-slate-500">Weekly campus-wide presence</p>
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {metrics.attendanceRate}% Current
              </span>
            </div>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={attendanceTrendData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="attendanceGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#059669" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="week" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis domain={[80, 100]} tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '6px', color: '#fff', fontSize: '11px' }}
                  />
                  <Area type="monotone" dataKey="rate" stroke="#059669" strokeWidth={2} fillOpacity={1} fill="url(#attendanceGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Senate Minimum Requirement:</span>
            <span className="font-bold text-slate-700">75.0%</span>
          </div>
        </div>

      </div>

      {/* Two Column Layout: Today's Schedule & Campus Bulletins */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Today's Classes & Timetable preview */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              <h2 className="text-sm font-bold text-slate-900">Active Course Schedule</h2>
            </div>
            <button 
              onClick={() => setActiveTab('timetable')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
            >
              Full Timetable →
            </button>
          </div>

          <div className="space-y-3">
            {courses.slice(0, 4).map(course => (
              <div 
                key={course.id} 
                className="p-3 rounded-lg bg-slate-50 border border-slate-200/80 hover:bg-slate-100/70 transition flex items-center justify-between"
              >
                <div className="flex items-start space-x-3">
                  <div className="w-12 h-10 rounded bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center shrink-0">
                    {course.code.split('-')[0]}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-xs text-slate-900">{course.code}: {course.title}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-white text-slate-600 border border-slate-200">
                        {course.credits} Cr
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 mt-1 text-[11px] text-slate-500">
                      <span>{course.instructorName}</span>
                      <span>•</span>
                      <span>{course.schedule[0]?.room || 'Main Hall'}</span>
                      <span>•</span>
                      <span className="text-slate-700 font-medium">{course.schedule[0]?.day} {course.schedule[0]?.time}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-semibold text-slate-700">{course.enrolledCount}/{course.capacity}</span>
                  <span className="block text-[10px] text-slate-400">seats</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Urgent Campus Bulletins & Notices */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Megaphone className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-900">Campus Bulletins & Notices</h2>
            </div>
            <button 
              onClick={() => setActiveTab('announcements')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
            >
              All Bulletins ({announcements.length}) →
            </button>
          </div>

          <div className="space-y-3">
            {announcements.slice(0, 3).map(ann => (
              <div 
                key={ann.id} 
                className="p-3 rounded-lg border border-slate-200 bg-white hover:border-slate-300 transition"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    ann.priority === 'Urgent' 
                      ? 'bg-rose-100 text-rose-800 border border-rose-200' 
                      : ann.priority === 'Standard'
                        ? 'bg-amber-100 text-amber-800 border border-amber-200'
                        : 'bg-slate-100 text-slate-700 border border-slate-200'
                  }`}>
                    {ann.priority}
                  </span>
                  <span className="text-[10px] text-slate-400">{ann.date}</span>
                </div>
                <h3 className="text-xs font-bold text-slate-900 mb-1">{ann.title}</h3>
                <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">{ann.content}</p>
                <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500">
                  <span>Posted by: <strong className="text-slate-700">{ann.author}</strong> ({ann.authorRole})</span>
                  <span className="text-slate-400">{ann.category}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
