import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { Course, Department } from '../../types';
import { DEPARTMENTS } from '../../data/mockData';
import { 
  BookOpen, 
  Search, 
  Plus, 
  Calendar, 
  MapPin, 
  Users, 
  Award, 
  CheckCircle, 
  FileText,
  Trash2,
  X,
  Clock,
  Layers
} from 'lucide-react';

export const CoursesView: React.FC = () => {
  const { 
    courses, 
    addCourse, 
    deleteCourse, 
    faculty, 
    students, 
    role, 
    activeStudentId, 
    updateStudent 
  } = useUniversity();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const activeStudent = students.find(s => s.studentId === activeStudentId);

  const [newCourse, setNewCourse] = useState({
    code: 'CS-420',
    title: '',
    department: 'Computer Science & AI' as Department,
    credits: 3,
    instructorId: faculty[0]?.id || 'f1',
    instructorName: faculty[0]?.name || 'Dr. Eleanor Vance',
    semester: 5,
    schedule: [
      { day: 'Mon' as const, time: '11:00 - 12:30', room: 'Hall B-201' },
      { day: 'Wed' as const, time: '11:00 - 12:30', room: 'Hall B-201' }
    ],
    capacity: 50,
    enrolledCount: 1,
    syllabus: 'In-depth exploration of state-of-the-art computational systems, modern theoretical principles, and experimental methodologies.',
    prerequisites: ['CS-301']
  });

  const filteredCourses = courses.filter(c => {
    const matchesSearch = 
      c.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.instructorName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDept = selectedDept === 'All' || c.department === selectedDept;

    return matchesSearch && matchesDept;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCourse.code || !newCourse.title) return;

    const assignedInstructor = faculty.find(f => f.id === newCourse.instructorId);
    addCourse({
      ...newCourse,
      instructorName: assignedInstructor?.name || newCourse.instructorName
    });

    setIsAddModalOpen(false);
  };

  const handleToggleStudentEnrollment = (courseCode: string) => {
    if (!activeStudent) return;
    const isEnrolled = activeStudent.enrolledCourseCodes.includes(courseCode);
    let updatedCodes: string[];
    if (isEnrolled) {
      updatedCodes = activeStudent.enrolledCourseCodes.filter(c => c !== courseCode);
    } else {
      updatedCodes = [...activeStudent.enrolledCourseCodes, courseCode];
    }
    updateStudent(activeStudent.id, { enrolledCourseCodes: updatedCodes });
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">University Course Catalog & Curriculum</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Accredited course offerings, credit allocations, lecture hall schedules, and instructor assignments.
          </p>
        </div>

        {role === 'admin' && (
          <button
            id="btn-add-course-modal"
            onClick={() => setIsAddModalOpen(true)}
            className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Create New Course</span>
          </button>
        )}
      </div>

      {/* Filter & Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="course-search-input"
            type="text"
            placeholder="Search by course code (e.g. CS-301), title, or instructor..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
          />
        </div>

        <div className="w-full md:w-64">
          <select
            id="course-dept-filter"
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="All">All Departments</option>
            {DEPARTMENTS.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredCourses.map(course => {
          const isStudentEnrolled = activeStudent?.enrolledCourseCodes.includes(course.code);
          const percentFull = Math.min(100, Math.round((course.enrolledCount / course.capacity) * 100));

          return (
            <div 
              key={course.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition flex flex-col justify-between"
            >
              <div>
                {/* Course Code & Credit Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-xs px-2.5 py-1 rounded bg-slate-900 text-white">
                        {course.code}
                      </span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                        {course.credits} Credits
                      </span>
                      <span className="text-xs font-semibold text-slate-500">
                        Sem {course.semester}
                      </span>
                    </div>
                    <h3 className="font-bold text-sm text-slate-900 mt-2">{course.title}</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">{course.department}</p>
                  </div>

                  {role === 'admin' && (
                    <button
                      onClick={() => deleteCourse(course.id)}
                      className="text-slate-400 hover:text-rose-600 p-1"
                      title="Delete Course"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Syllabus Excerpt */}
                <p className="text-xs text-slate-600 mt-3 line-clamp-2 leading-relaxed">
                  {course.syllabus}
                </p>

                {/* Instructor */}
                <div className="mt-4 flex items-center space-x-2 text-xs text-slate-700">
                  <span className="text-slate-400 text-[11px]">Instructor:</span>
                  <strong className="font-semibold text-slate-800">{course.instructorName}</strong>
                </div>

                {/* Schedule Slots */}
                <div className="mt-3 space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    Class Schedule & Room
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {course.schedule.map((slot, idx) => (
                      <div key={idx} className="flex items-center space-x-1.5 text-[11px] bg-slate-50 border border-slate-200 px-2 py-1 rounded text-slate-600">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span className="font-semibold text-slate-800">{slot.day}</span>
                        <span>{slot.time}</span>
                        <span className="text-slate-300">|</span>
                        <span className="text-slate-500">{slot.room}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Capacity Progress Bar */}
                <div className="mt-4">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-slate-500">Class Enrollment:</span>
                    <span className="font-semibold text-slate-700">{course.enrolledCount} / {course.capacity} students ({percentFull}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${percentFull > 90 ? 'bg-amber-500' : 'bg-slate-800'}`}
                      style={{ width: `${percentFull}%` }}
                    />
                  </div>
                </div>

              </div>

              {/* Bottom Actions */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => setSelectedCourse(course)}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>View Details & Roster</span>
                </button>

                {role === 'student' && (
                  <button
                    onClick={() => handleToggleStudentEnrollment(course.code)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                      isStudentEnrolled
                        ? 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}
                  >
                    {isStudentEnrolled ? 'Drop Course' : 'Enroll Now'}
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Course Detail Modal */}
      {selectedCourse && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="font-mono text-xs font-bold text-amber-600">{selectedCourse.code}</span>
                <h2 className="text-base font-bold text-slate-900">{selectedCourse.title}</h2>
              </div>
              <button 
                onClick={() => setSelectedCourse(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div>
                <h4 className="font-bold text-slate-700 uppercase tracking-wider text-[10px] mb-1">Academic Department</h4>
                <p className="text-slate-800 font-medium">{selectedCourse.department} • {selectedCourse.credits} Credit Hours</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-700 uppercase tracking-wider text-[10px] mb-1">Course Syllabus</h4>
                <p className="text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-200">
                  {selectedCourse.syllabus}
                </p>
              </div>

              <div>
                <h4 className="font-bold text-slate-700 uppercase tracking-wider text-[10px] mb-1">Prerequisites</h4>
                <div className="flex gap-2">
                  {selectedCourse.prerequisites.map(p => (
                    <span key={p} className="px-2 py-0.5 rounded bg-slate-100 font-medium text-slate-700">
                      {p}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-700 uppercase tracking-wider text-[10px] mb-1">
                  Enrolled Students in this Course
                </h4>
                <div className="max-h-40 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">
                  {students.filter(s => s.enrolledCourseCodes.includes(selectedCourse.code)).map(s => (
                    <div key={s.id} className="p-2.5 flex items-center justify-between hover:bg-slate-50">
                      <div className="flex items-center space-x-2">
                        <img src={s.avatar} alt={s.name} className="w-6 h-6 rounded-full object-cover" />
                        <div>
                          <span className="font-semibold text-slate-800 block">{s.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{s.studentId}</span>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        Sem {s.semester}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedCourse(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Course Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">Add Academic Course</h2>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Course Code</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CS-450"
                    value={newCourse.code}
                    onChange={(e) => setNewCourse({ ...newCourse, code: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Credits</label>
                  <select
                    value={newCourse.credits}
                    onChange={(e) => setNewCourse({ ...newCourse, credits: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    {[1, 2, 3, 4, 5].map(c => (
                      <option key={c} value={c}>{c} Credit Hours</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Course Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Quantum Computing Architectures"
                  value={newCourse.title}
                  onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={newCourse.department}
                    onChange={(e) => setNewCourse({ ...newCourse, department: e.target.value as Department })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    {DEPARTMENTS.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assigned Instructor</label>
                  <select
                    value={newCourse.instructorId}
                    onChange={(e) => {
                      const fac = faculty.find(f => f.id === e.target.value);
                      setNewCourse({ 
                        ...newCourse, 
                        instructorId: e.target.value,
                        instructorName: fac ? fac.name : newCourse.instructorName
                      });
                    }}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    {faculty.map(f => (
                      <option key={f.id} value={f.id}>{f.name} ({f.department.split(' ')[0]})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Syllabus Overview</label>
                <textarea
                  rows={3}
                  value={newCourse.syllabus}
                  onChange={(e) => setNewCourse({ ...newCourse, syllabus: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition"
                >
                  Create Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
