import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { 
  GraduationCap, 
  Award, 
  CheckCircle, 
  BookOpen, 
  Calendar, 
  CreditCard, 
  AlertTriangle, 
  ArrowUpRight, 
  Printer, 
  Clock, 
  MapPin,
  ChevronRight,
  TrendingUp,
  FileText
} from 'lucide-react';

interface StudentPortalViewProps {
  setActiveTab: (tab: string) => void;
}

export const StudentPortalView: React.FC<StudentPortalViewProps> = ({ setActiveTab }) => {
  const { 
    activeStudentId, 
    students, 
    courses, 
    grades, 
    fees, 
    getAttendanceForStudent, 
    announcements,
    payFeeInvoice 
  } = useUniversity();

  const activeStudent = students.find(s => s.studentId === activeStudentId) || students[0];
  const enrolledCourses = courses.filter(c => activeStudent?.enrolledCourseCodes.includes(c.code));
  const studentGrades = grades.filter(g => g.studentId === activeStudent?.studentId);
  const studentFees = fees.filter(f => f.studentId === activeStudent?.studentId);
  const overallAttendance = getAttendanceForStudent(activeStudent?.studentId);

  const pendingInvoice = studentFees.find(f => f.status !== 'Paid');
  const degreeProgressPercent = Math.min(100, Math.round(((activeStudent?.creditsCompleted || 0) / 120) * 100));

  return (
    <div className="space-y-6">
      
      {/* Student Welcome Banner */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div className="flex items-center space-x-4">
          <img 
            src={activeStudent?.avatar} 
            alt={activeStudent?.name} 
            className="w-16 h-16 rounded-full object-cover ring-2 ring-slate-200 shrink-0" 
          />
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-bold text-slate-900">{activeStudent?.name}</h1>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                activeStudent?.status === 'Active' 
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {activeStudent?.status}
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              {activeStudent?.department} • Semester {activeStudent?.semester} (Year {activeStudent?.year})
            </p>
            <div className="flex items-center space-x-3 text-[11px] text-slate-400 mt-1">
              <span className="font-mono font-semibold text-slate-700">ID: {activeStudent?.studentId}</span>
              <span>•</span>
              <span>Advisor: {activeStudent?.advisor}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          <button
            onClick={() => setActiveTab('gradebook')}
            className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>Academic Transcript</span>
          </button>
        </div>
      </div>

      {/* Academic Standing & Progress Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Cumulative CGPA */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block mb-1">Cumulative CGPA</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-slate-900">{activeStudent?.cgpa.toFixed(2)}</span>
            <span className="text-xs text-slate-400 font-medium">/ 4.00</span>
          </div>
          <span className="text-[11px] text-emerald-600 font-medium block mt-1">
            Current Semester GPA: {activeStudent?.gpa.toFixed(2)}
          </span>
        </div>

        {/* Degree Completion Progress */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-semibold text-slate-500">Degree Progress</span>
            <span className="text-xs font-bold text-slate-900">{degreeProgressPercent}%</span>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {activeStudent?.creditsCompleted} <span className="text-xs font-normal text-slate-400">/ 120 Credits</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div 
              className="h-full rounded-full bg-slate-900"
              style={{ width: `${degreeProgressPercent}%` }}
            />
          </div>
        </div>

        {/* Semester Attendance */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block mb-1">Semester Attendance</span>
          <div className="flex items-baseline space-x-2">
            <span className={`text-2xl font-bold ${overallAttendance.rate < 75 ? 'text-rose-600' : 'text-emerald-600'}`}>
              {overallAttendance.rate}%
            </span>
            <span className="text-xs text-slate-400 font-medium">
              ({overallAttendance.present}/{overallAttendance.total} lectures)
            </span>
          </div>
          <span className={`text-[11px] font-medium block mt-1 ${overallAttendance.rate < 75 ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
            {overallAttendance.rate < 75 ? 'Warning: Below Senate 75% limit' : 'Good Standing (Eligible for exams)'}
          </span>
        </div>

        {/* Tuition Fee Status */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 block mb-1">Tuition Dues</span>
            <div className="flex items-baseline space-x-1">
              <span className={`text-2xl font-bold ${pendingInvoice ? 'text-rose-600' : 'text-emerald-600'}`}>
                ${pendingInvoice ? (pendingInvoice.totalAmount - pendingInvoice.paidAmount).toLocaleString() : '0'}
              </span>
              <span className="text-xs text-slate-400">Balance</span>
            </div>
          </div>
          {pendingInvoice ? (
            <button
              onClick={() => setActiveTab('fees')}
              className="mt-2 text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Settle Dues Now</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <span className="text-[11px] text-emerald-600 font-semibold mt-1">All accounts settled</span>
          )}
        </div>

      </div>

      {/* Enrolled Courses & Attendance Status */}
      <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Enrolled Courses ({enrolledCourses.length})</h2>
            <p className="text-xs text-slate-500">Active Fall 2026 courses, instructors, and individual attendance tracking</p>
          </div>
          <button
            onClick={() => setActiveTab('courses')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            Course Catalog →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {enrolledCourses.map(course => {
            const courseAtt = getAttendanceForStudent(activeStudent?.studentId, course.code);
            const courseGrade = studentGrades.find(g => g.courseCode === course.code);

            return (
              <div 
                key={course.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-900 text-white">
                          {course.code}
                        </span>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-white text-slate-600 border border-slate-200">
                          {course.credits} Credits
                        </span>
                      </div>
                      <h3 className="font-bold text-xs text-slate-900 mt-2">{course.title}</h3>
                      <p className="text-[11px] text-slate-500">Instructor: {course.instructorName}</p>
                    </div>

                    {courseGrade && (
                      <span className="font-bold px-2 py-1 rounded bg-white border border-slate-200 text-slate-800 text-xs shadow-xs">
                        Grade: <span className="text-emerald-700">{courseGrade.letterGrade}</span>
                      </span>
                    )}
                  </div>

                  {/* Schedule */}
                  <div className="mt-3 flex items-center space-x-2 text-[11px] text-slate-600">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{course.schedule[0]?.day} {course.schedule[0]?.time}</span>
                    <span>•</span>
                    <span>{course.schedule[0]?.room}</span>
                  </div>
                </div>

                {/* Course Attendance meter */}
                <div className="mt-4 pt-3 border-t border-slate-200/80">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-slate-500">Lecture Attendance:</span>
                    <span className={`font-bold ${courseAtt.rate < 75 ? 'text-rose-600' : 'text-emerald-700'}`}>
                      {courseAtt.rate}% ({courseAtt.present}/{courseAtt.total} sessions)
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${courseAtt.rate < 75 ? 'bg-rose-500' : 'bg-emerald-600'}`}
                      style={{ width: `${courseAtt.rate}%` }}
                    />
                  </div>
                  {courseAtt.rate < 75 && (
                    <span className="text-[10px] text-rose-600 font-bold block mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      Attendance below 75% bar. Risk of examination disqualification.
                    </span>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
