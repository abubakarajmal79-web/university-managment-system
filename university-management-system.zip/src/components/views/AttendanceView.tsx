import React, { useState, useEffect } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { AttendanceStatusType } from '../../types';
import { 
  CheckSquare, 
  Calendar, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Save, 
  Sparkles,
  Check,
  History
} from 'lucide-react';

export const AttendanceView: React.FC = () => {
  const { 
    courses, 
    students, 
    attendance, 
    saveAttendanceSession, 
    getAttendanceForStudent, 
    role, 
    activeFacultyId, 
    faculty 
  } = useUniversity();

  // For faculty, prefer their course, otherwise default to first course
  const currentFaculty = faculty.find(f => f.id === activeFacultyId);
  const defaultCourse = (role === 'faculty' && currentFaculty?.courseCodes[0]) 
    ? courses.find(c => c.code === currentFaculty.courseCodes[0])?.code || courses[0]?.code
    : courses[0]?.code || 'CS-301';

  const [selectedCourseCode, setSelectedCourseCode] = useState(defaultCourse);
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [studentRecords, setStudentRecords] = useState<Record<string, AttendanceStatusType>>({});
  const [showSavedNotification, setShowSavedNotification] = useState(false);

  const activeCourse = courses.find(c => c.code === selectedCourseCode) || courses[0];
  const enrolledStudents = students.filter(s => s.enrolledCourseCodes.includes(selectedCourseCode));

  // Load existing attendance for this course & date or initialize defaults
  useEffect(() => {
    const existingSession = attendance.find(a => a.courseCode === selectedCourseCode && a.date === selectedDate);
    const initialRecords: Record<string, AttendanceStatusType> = {};

    enrolledStudents.forEach(student => {
      if (existingSession && existingSession.records[student.studentId]) {
        initialRecords[student.studentId] = existingSession.records[student.studentId];
      } else {
        // Default to 'present' for ease of marking
        initialRecords[student.studentId] = 'present';
      }
    });

    setStudentRecords(initialRecords);
  }, [selectedCourseCode, selectedDate, enrolledStudents.length]);

  const setStatusForStudent = (studentId: string, status: AttendanceStatusType) => {
    setStudentRecords(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const handleMarkAll = (status: AttendanceStatusType) => {
    const updated: Record<string, AttendanceStatusType> = {};
    enrolledStudents.forEach(s => {
      updated[s.studentId] = status;
    });
    setStudentRecords(updated);
  };

  const handleSaveAttendance = () => {
    saveAttendanceSession(selectedCourseCode, selectedDate, studentRecords);
    setShowSavedNotification(true);
    setTimeout(() => setShowSavedNotification(false), 3000);
  };

  // Calculate live stats for this session
  const total = enrolledStudents.length;
  const presentCount = Object.values(studentRecords).filter(s => s === 'present').length;
  const lateCount = Object.values(studentRecords).filter(s => s === 'late').length;
  const absentCount = Object.values(studentRecords).filter(s => s === 'absent').length;
  const excusedCount = Object.values(studentRecords).filter(s => s === 'excused').length;
  const sessionRate = total > 0 ? Math.round(((presentCount + (lateCount * 0.8) + excusedCount) / total) * 100) : 100;

  // Previous sessions for this course
  const pastSessions = attendance.filter(a => a.courseCode === selectedCourseCode);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Interactive Attendance Tracker</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Log lecture presence, flag attendance anomalies, and track Senate compliance thresholds.
          </p>
        </div>

        <button
          id="btn-save-attendance"
          onClick={handleSaveAttendance}
          className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
        >
          <Save className="w-4 h-4 text-amber-400" />
          <span>Save Attendance Record</span>
        </button>
      </div>

      {/* Confirmation notification */}
      {showSavedNotification && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-lg text-xs flex items-center space-x-2 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-600" />
          <span className="font-semibold">Attendance recorded successfully for {selectedCourseCode} on {selectedDate}.</span>
        </div>
      )}

      {/* Course & Date Picker Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full md:w-auto">
          {/* Select Course */}
          <div>
            <label className="block font-semibold text-slate-700 text-xs mb-1">Target Academic Course</label>
            <select
              id="attendance-course-select"
              value={selectedCourseCode}
              onChange={(e) => setSelectedCourseCode(e.target.value)}
              className="w-full sm:w-64 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden"
            >
              {courses.map(c => (
                <option key={c.id} value={c.code}>
                  {c.code} - {c.title}
                </option>
              ))}
            </select>
          </div>

          {/* Select Date */}
          <div>
            <label className="block font-semibold text-slate-700 text-xs mb-1">Lecture Date</label>
            <input
              id="attendance-date-input"
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full sm:w-48 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden"
            >
            </input>
          </div>
        </div>

        {/* Quick Batch Marking Buttons */}
        <div className="flex items-center space-x-2 self-end md:self-center">
          <span className="text-[11px] text-slate-400 font-semibold mr-1">Batch Actions:</span>
          <button
            id="mark-all-present"
            onClick={() => handleMarkAll('present')}
            className="px-2.5 py-1.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 text-xs font-semibold transition"
          >
            All Present
          </button>
          <button
            id="mark-all-absent"
            onClick={() => handleMarkAll('absent')}
            className="px-2.5 py-1.5 rounded bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 text-xs font-semibold transition"
          >
            All Absent
          </button>
        </div>

      </div>

      {/* Session Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Total Enrolled</span>
          <span className="text-lg font-bold text-slate-900">{total} Students</span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Present</span>
          <span className="text-lg font-bold text-emerald-600">{presentCount}</span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Late</span>
          <span className="text-lg font-bold text-amber-600">{lateCount}</span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Absent</span>
          <span className="text-lg font-bold text-rose-600">{absentCount}</span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 col-span-2 sm:col-span-1">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Session Rate</span>
          <span className={`text-lg font-bold ${sessionRate < 75 ? 'text-rose-600' : 'text-emerald-600'}`}>
            {sessionRate}%
          </span>
        </div>
      </div>

      {/* Students Marking Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Student Roll Call for {selectedCourseCode} ({selectedDate})
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            Instructor: {activeCourse?.instructorName}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-4 text-center">Course Cumulative Attendance</th>
                <th className="py-3 px-4 text-center">Attendance Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {enrolledStudents.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-10 text-center text-slate-400">
                    No students currently enrolled in this course.
                  </td>
                </tr>
              ) : (
                enrolledStudents.map(student => {
                  const currentStatus = studentRecords[student.studentId] || 'present';
                  const cumulative = getAttendanceForStudent(student.studentId, selectedCourseCode);

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/50 transition">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <img 
                            src={student.avatar} 
                            alt={student.name} 
                            className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200" 
                          />
                          <div>
                            <span className="font-bold text-slate-900 block">{student.name}</span>
                            <span className="text-[10px] text-slate-400">{student.department}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-semibold text-slate-700">
                        {student.studentId}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span className={`font-bold px-2 py-0.5 rounded text-xs ${
                          cumulative.rate < 75 
                            ? 'bg-rose-50 text-rose-700 border border-rose-200' 
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {cumulative.rate}% ({cumulative.present}/{cumulative.total} classes)
                        </span>
                        {cumulative.rate < 75 && (
                          <span className="block text-[9px] text-rose-600 font-bold mt-0.5">
                            Under 75% Senate Mandate
                          </span>
                        )}
                      </td>

                      {/* Interactive 4-Way Status Toggle */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex rounded-lg p-1 bg-slate-100 border border-slate-200 space-x-1">
                          
                          <button
                            id={`att-${student.studentId}-present`}
                            type="button"
                            onClick={() => setStatusForStudent(student.studentId, 'present')}
                            className={`px-3 py-1 rounded text-xs font-semibold transition ${
                              currentStatus === 'present'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            Present
                          </button>

                          <button
                            id={`att-${student.studentId}-late`}
                            type="button"
                            onClick={() => setStatusForStudent(student.studentId, 'late')}
                            className={`px-3 py-1 rounded text-xs font-semibold transition ${
                              currentStatus === 'late'
                                ? 'bg-amber-500 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            Late
                          </button>

                          <button
                            id={`att-${student.studentId}-absent`}
                            type="button"
                            onClick={() => setStatusForStudent(student.studentId, 'absent')}
                            className={`px-3 py-1 rounded text-xs font-semibold transition ${
                              currentStatus === 'absent'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            Absent
                          </button>

                          <button
                            id={`att-${student.studentId}-excused`}
                            type="button"
                            onClick={() => setStatusForStudent(student.studentId, 'excused')}
                            className={`px-3 py-1 rounded text-xs font-semibold transition ${
                              currentStatus === 'excused'
                                ? 'bg-slate-700 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            Excused
                          </button>

                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Session History Drawer / Box */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center space-x-2 mb-3">
          <History className="w-4 h-4 text-slate-500" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Previous Logged Sessions for {selectedCourseCode}
          </h3>
        </div>

        {pastSessions.length === 0 ? (
          <p className="text-xs text-slate-400">No previous attendance logs on file for this course.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {pastSessions.map(session => {
              const pCount = Object.values(session.records).filter(r => r === 'present').length;
              const aCount = Object.values(session.records).filter(r => r === 'absent').length;
              return (
                <div 
                  key={session.id}
                  onClick={() => setSelectedDate(session.date)}
                  className={`p-3 rounded-lg border text-xs cursor-pointer transition ${
                    selectedDate === session.date 
                      ? 'border-slate-900 bg-slate-50 font-semibold' 
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-800">{session.date}</span>
                    <span className="text-[10px] text-slate-400">Click to view</span>
                  </div>
                  <div className="flex items-center space-x-3 text-[11px] text-slate-600">
                    <span className="text-emerald-700">{pCount} Present</span>
                    <span>•</span>
                    <span className="text-rose-700">{aCount} Absent</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
