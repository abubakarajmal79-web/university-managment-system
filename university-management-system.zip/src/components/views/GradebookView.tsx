import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { GradeEntry, Student } from '../../types';
import { 
  Award, 
  Search, 
  FileSpreadsheet, 
  Printer, 
  CheckCircle, 
  Save, 
  Sparkles, 
  Eye, 
  X,
  FileText,
  GraduationCap
} from 'lucide-react';

export const GradebookView: React.FC = () => {
  const { 
    courses, 
    students, 
    grades, 
    saveGradeEntry, 
    updateGradeEntry, 
    role, 
    activeFacultyId, 
    faculty 
  } = useUniversity();

  const currentFaculty = faculty.find(f => f.id === activeFacultyId);
  const defaultCourse = (role === 'faculty' && currentFaculty?.courseCodes[0]) 
    ? courses.find(c => c.code === currentFaculty.courseCodes[0])?.code || courses[0]?.code
    : courses[0]?.code || 'CS-301';

  const [selectedCourseCode, setSelectedCourseCode] = useState(defaultCourse);
  const [selectedTranscriptStudent, setSelectedTranscriptStudent] = useState<Student | null>(null);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);

  const activeCourse = courses.find(c => c.code === selectedCourseCode) || courses[0];
  const enrolledStudents = students.filter(s => s.enrolledCourseCodes.includes(selectedCourseCode));

  // Find or generate editable grade entries for all enrolled students
  const studentGrades = enrolledStudents.map(student => {
    const existing = grades.find(g => g.studentId === student.studentId && g.courseCode === selectedCourseCode);
    if (existing) return { student, grade: existing };
    
    // Default draft entry if none exists yet
    const dummyGrade: GradeEntry = {
      id: `temp_${student.studentId}`,
      studentId: student.studentId,
      studentName: student.name,
      courseCode: selectedCourseCode,
      semester: student.semester,
      assignmentsScore: 17,
      midtermScore: 25,
      finalExamScore: 40,
      totalScore: 82,
      letterGrade: 'B+',
      gradePoint: 3.3,
      status: 'Draft'
    };
    return { student, grade: dummyGrade };
  });

  const handleScoreChange = (
    student: Student, 
    currentGrade: GradeEntry, 
    field: 'assignmentsScore' | 'midtermScore' | 'finalExamScore', 
    val: number
  ) => {
    const clamped = Math.max(0, val);
    const updatedAssignments = field === 'assignmentsScore' ? Math.min(20, clamped) : currentGrade.assignmentsScore;
    const updatedMidterm = field === 'midtermScore' ? Math.min(30, clamped) : currentGrade.midtermScore;
    const updatedFinal = field === 'finalExamScore' ? Math.min(50, clamped) : currentGrade.finalExamScore;

    if (currentGrade.id.startsWith('temp_')) {
      saveGradeEntry({
        studentId: student.studentId,
        studentName: student.name,
        courseCode: selectedCourseCode,
        semester: student.semester,
        assignmentsScore: updatedAssignments,
        midtermScore: updatedMidterm,
        finalExamScore: updatedFinal,
        status: 'Draft'
      });
    } else {
      updateGradeEntry(currentGrade.id, {
        [field]: clamped
      });
    }
  };

  const handlePublishAll = () => {
    studentGrades.forEach(({ student, grade }) => {
      if (grade.id.startsWith('temp_')) {
        saveGradeEntry({
          studentId: student.studentId,
          studentName: student.name,
          courseCode: selectedCourseCode,
          semester: student.semester,
          assignmentsScore: grade.assignmentsScore,
          midtermScore: grade.midtermScore,
          finalExamScore: grade.finalExamScore,
          status: 'Published'
        });
      } else {
        updateGradeEntry(grade.id, { status: 'Published' });
      }
    });

    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 3000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Academic Gradebook & Examination Ledger</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Continuous assessment weights, final exams submission, letter grade conversions, and certified transcripts.
          </p>
        </div>

        <button
          id="btn-publish-grades"
          onClick={handlePublishAll}
          className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
        >
          <CheckCircle className="w-4 h-4 text-amber-400" />
          <span>Publish Course Grades</span>
        </button>
      </div>

      {saveSuccessNotice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-lg text-xs flex items-center space-x-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span className="font-semibold">All grades for {selectedCourseCode} committed and published to Student Portals.</span>
        </div>
      )}

      {/* Course Selector & Weighting Legend */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="w-full md:w-80">
          <label className="block font-semibold text-slate-700 text-xs mb-1">Target Course Roster</label>
          <select
            id="gradebook-course-select"
            value={selectedCourseCode}
            onChange={(e) => setSelectedCourseCode(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden"
          >
            {courses.map(c => (
              <option key={c.id} value={c.code}>
                {c.code} - {c.title} ({c.credits} Cr)
              </option>
            ))}
          </select>
        </div>

        {/* Grading Weighting Scheme Pill */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs flex flex-wrap items-center gap-4 text-slate-600">
          <span className="font-bold text-slate-800 text-[11px] uppercase tracking-wider">Senate Weightings:</span>
          <span>Assignments (20%)</span>
          <span className="text-slate-300">•</span>
          <span>Midterm (30%)</span>
          <span className="text-slate-300">•</span>
          <span>Final Exam (50%)</span>
          <span className="text-slate-300">•</span>
          <span className="font-semibold text-slate-800">Total (100 pts)</span>
        </div>
      </div>

      {/* Grade Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              {selectedCourseCode}: {activeCourse?.title}
            </h2>
            <p className="text-[11px] text-slate-500">Instructor: {activeCourse?.instructorName}</p>
          </div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
            {enrolledStudents.length} Students Registered
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-3 text-center">Assignments (Max 20)</th>
                <th className="py-3 px-3 text-center">Midterm (Max 30)</th>
                <th className="py-3 px-3 text-center">Final Exam (Max 50)</th>
                <th className="py-3 px-3 text-center">Total (100)</th>
                <th className="py-3 px-3 text-center">Letter Grade</th>
                <th className="py-3 px-3 text-center">GPA (4.0)</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Transcript</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {studentGrades.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-10 text-center text-slate-400">
                    No students currently enrolled in this course.
                  </td>
                </tr>
              ) : (
                studentGrades.map(({ student, grade }) => (
                  <tr key={student.id} className="hover:bg-slate-50/60 transition">
                    
                    {/* Student Info */}
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2.5">
                        <img src={student.avatar} alt={student.name} className="w-7 h-7 rounded-full object-cover" />
                        <div>
                          <span className="font-bold text-slate-900 block leading-tight">{student.name}</span>
                          <span className="text-[10px] text-slate-400">{student.department}</span>
                        </div>
                      </div>
                    </td>

                    {/* ID */}
                    <td className="py-3 px-4 font-mono font-semibold text-slate-700">
                      {student.studentId}
                    </td>

                    {/* Assignments Input */}
                    <td className="py-3 px-3 text-center">
                      <input
                        type="number"
                        min={0}
                        max={20}
                        step={0.5}
                        value={grade.assignmentsScore}
                        onChange={(e) => handleScoreChange(student, grade, 'assignmentsScore', parseFloat(e.target.value) || 0)}
                        className="w-16 text-center py-1 border border-slate-200 rounded font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:ring-1 focus:ring-slate-900"
                      />
                    </td>

                    {/* Midterm Input */}
                    <td className="py-3 px-3 text-center">
                      <input
                        type="number"
                        min={0}
                        max={30}
                        step={0.5}
                        value={grade.midtermScore}
                        onChange={(e) => handleScoreChange(student, grade, 'midtermScore', parseFloat(e.target.value) || 0)}
                        className="w-16 text-center py-1 border border-slate-200 rounded font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:ring-1 focus:ring-slate-900"
                      />
                    </td>

                    {/* Final Exam Input */}
                    <td className="py-3 px-3 text-center">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        step={0.5}
                        value={grade.finalExamScore}
                        onChange={(e) => handleScoreChange(student, grade, 'finalExamScore', parseFloat(e.target.value) || 0)}
                        className="w-16 text-center py-1 border border-slate-200 rounded font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:ring-1 focus:ring-slate-900"
                      />
                    </td>

                    {/* Computed Total */}
                    <td className="py-3 px-3 text-center font-bold text-slate-900">
                      {grade.totalScore}
                    </td>

                    {/* Letter Grade */}
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-block font-bold px-2 py-0.5 rounded text-xs ${
                        grade.letterGrade.startsWith('A')
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : grade.letterGrade.startsWith('B')
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {grade.letterGrade}
                      </span>
                    </td>

                    {/* GPA Point */}
                    <td className="py-3 px-3 text-center font-mono font-bold text-slate-700">
                      {grade.gradePoint.toFixed(1)}
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-3 text-center">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        grade.status === 'Published'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}>
                        {grade.status}
                      </span>
                    </td>

                    {/* Transcript Button */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedTranscriptStudent(student)}
                        className="px-2.5 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded text-xs font-semibold flex items-center gap-1 ml-auto transition"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Transcript</span>
                      </button>
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Academic Transcript Modal */}
      {selectedTranscriptStudent && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-8 border border-slate-200 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            
            {/* Institution Letterhead */}
            <div className="text-center pb-6 border-b-2 border-slate-800">
              <div className="flex items-center justify-center space-x-2 mb-1">
                <GraduationCap className="w-7 h-7 text-slate-900" />
                <h2 className="text-xl font-bold tracking-tight text-slate-900">APEX STATE UNIVERSITY</h2>
              </div>
              <p className="text-xs font-bold text-slate-600 uppercase tracking-widest">Office of the University Registrar</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Official Academic Transcript Record • Accredited Institution</p>
            </div>

            {/* Student Metadata Header */}
            <div className="grid grid-cols-2 gap-4 py-5 border-b border-slate-200 text-xs">
              <div>
                <p><span className="text-slate-500">Student Name:</span> <strong className="text-slate-900 font-bold">{selectedTranscriptStudent.name}</strong></p>
                <p className="mt-1"><span className="text-slate-500">Student ID:</span> <strong className="font-mono text-slate-900">{selectedTranscriptStudent.studentId}</strong></p>
                <p className="mt-1"><span className="text-slate-500">Department:</span> <strong className="text-slate-800">{selectedTranscriptStudent.department}</strong></p>
              </div>
              <div className="text-right">
                <p><span className="text-slate-500">Academic Standing:</span> <strong className="text-emerald-700 font-bold">{selectedTranscriptStudent.status} (Good Standing)</strong></p>
                <p className="mt-1"><span className="text-slate-500">Enrollment Date:</span> <strong className="text-slate-800">{selectedTranscriptStudent.enrollmentDate}</strong></p>
                <p className="mt-1"><span className="text-slate-500">Credits Completed:</span> <strong className="text-slate-900">{selectedTranscriptStudent.creditsCompleted} Credits</strong></p>
              </div>
            </div>

            {/* Course Grades Breakdown */}
            <div className="py-4">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">Current Semester Course Evaluation</h3>
              <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
                <thead className="bg-slate-50 font-bold text-slate-500 text-[10px] uppercase">
                  <tr>
                    <th className="p-2.5">Course Code</th>
                    <th className="p-2.5">Course Title</th>
                    <th className="p-2.5 text-center">Credits</th>
                    <th className="p-2.5 text-center">Score</th>
                    <th className="p-2.5 text-center">Grade</th>
                    <th className="p-2.5 text-center">Points</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {grades.filter(g => g.studentId === selectedTranscriptStudent.studentId).map(g => {
                    const courseObj = courses.find(c => c.code === g.courseCode);
                    return (
                      <tr key={g.id}>
                        <td className="p-2.5 font-bold font-mono text-slate-900">{g.courseCode}</td>
                        <td className="p-2.5 text-slate-700">{courseObj?.title || 'Academic Course'}</td>
                        <td className="p-2.5 text-center text-slate-600">{courseObj?.credits || 3}</td>
                        <td className="p-2.5 text-center text-slate-700">{g.totalScore}</td>
                        <td className="p-2.5 text-center font-bold text-slate-900">{g.letterGrade}</td>
                        <td className="p-2.5 text-center font-mono text-slate-800">{g.gradePoint.toFixed(1)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Overall GPA & Dean's Seal */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between text-xs my-4">
              <div>
                <span className="text-slate-500 block text-[11px]">Cumulative Grade Point Average (CGPA)</span>
                <span className="text-2xl font-bold text-slate-900">{selectedTranscriptStudent.cgpa.toFixed(2)}</span>
                <span className="text-slate-400 text-[10px] ml-1">/ 4.00 Maximum</span>
              </div>
              <div className="text-right">
                <span className="text-slate-500 block text-[11px]">Official Registrar Verification</span>
                <span className="text-xs font-bold text-slate-800">Certified Electronic Document</span>
              </div>
            </div>

            {/* Modal Controls */}
            <div className="mt-6 pt-4 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 flex items-center gap-1.5 transition"
              >
                <Printer className="w-4 h-4 text-slate-500" />
                <span>Print Official Copy</span>
              </button>

              <button
                onClick={() => setSelectedTranscriptStudent(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition"
              >
                Close Window
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
