import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { Student, Department, StudentStatus } from '../../types';
import { DEPARTMENTS } from '../../data/mockData';
import { 
  Users, 
  Search, 
  Plus, 
  Filter, 
  FileText, 
  Trash2, 
  Edit3, 
  ExternalLink, 
  Mail, 
  Phone, 
  Award, 
  BookOpen, 
  CheckCircle2, 
  AlertCircle,
  Download,
  X,
  GraduationCap,
  Printer
} from 'lucide-react';

export const StudentsView: React.FC = () => {
  const { 
    students, 
    addStudent, 
    updateStudent, 
    deleteStudent, 
    getAttendanceForStudent, 
    grades, 
    fees,
    role
  } = useUniversity();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State for Add Student
  const [newStudent, setNewStudent] = useState({
    name: '',
    email: '',
    studentId: `STU-2024-${String(students.length + 1).padStart(3, '0')}`,
    department: 'Computer Science & AI' as Department,
    semester: 1,
    year: 1,
    gpa: 3.5,
    cgpa: 3.5,
    status: 'Active' as StudentStatus,
    enrollmentDate: new Date().toISOString().split('T')[0],
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    phone: '+1 (555) 000-1122',
    advisor: 'Dr. Eleanor Vance',
    creditsCompleted: 15,
    enrolledCourseCodes: ['CS-301', 'MATH-220']
  });

  // Filter students
  const filteredStudents = students.filter(student => {
    const matchesSearch = 
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.department.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDept = selectedDept === 'All' || student.department === selectedDept;
    const matchesStatus = selectedStatus === 'All' || student.status === selectedStatus;

    return matchesSearch && matchesDept && matchesStatus;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudent.name || !newStudent.studentId) return;

    addStudent(newStudent);
    setIsAddModalOpen(false);
    // Reset form
    setNewStudent({
      name: '',
      email: '',
      studentId: `STU-2024-${String(students.length + 2).padStart(3, '0')}`,
      department: 'Computer Science & AI',
      semester: 1,
      year: 1,
      gpa: 3.5,
      cgpa: 3.5,
      status: 'Active',
      enrollmentDate: new Date().toISOString().split('T')[0],
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 000-1122',
      advisor: 'Dr. Eleanor Vance',
      creditsCompleted: 15,
      enrolledCourseCodes: ['CS-301', 'MATH-220']
    });
  };

  const handleExportCSV = () => {
    const headers = ['Student ID', 'Name', 'Department', 'Semester', 'CGPA', 'Status', 'Email'];
    const rows = filteredStudents.map(s => [
      s.studentId,
      `"${s.name}"`,
      `"${s.department}"`,
      s.semester,
      s.cgpa,
      s.status,
      s.email
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `apex_university_students_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Student Academic Directory</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage student records, academic standings, course enrollments, and official transcripts.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            id="btn-export-students"
            onClick={handleExportCSV}
            className="px-3 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>

          {role === 'admin' && (
            <button
              id="btn-add-student-modal"
              onClick={() => setIsAddModalOpen(true)}
              className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>Register Student</span>
            </button>
          )}
        </div>
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[11px] text-slate-500 block">Total Enrolled</span>
          <span className="text-lg font-bold text-slate-900">{students.length} Students</span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[11px] text-slate-500 block">Active Status</span>
          <span className="text-lg font-bold text-emerald-600">
            {students.filter(s => s.status === 'Active').length} Active
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[11px] text-slate-500 block">Academic Probation</span>
          <span className="text-lg font-bold text-rose-600">
            {students.filter(s => s.status === 'Probation').length} At Risk
          </span>
        </div>
        <div className="bg-white p-3.5 rounded-lg border border-slate-200">
          <span className="text-[11px] text-slate-500 block">Average Institutional CGPA</span>
          <span className="text-lg font-bold text-slate-900">
            {(students.reduce((a, b) => a + b.cgpa, 0) / students.length).toFixed(2)} / 4.00
          </span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        
        {/* Search box */}
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="student-search-input"
            type="text"
            placeholder="Search by student name, ID (e.g. STU-2024), or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
          />
        </div>

        {/* Department Filter */}
        <div className="w-full md:w-56">
          <select
            id="student-dept-filter"
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="All">All Departments</option>
            {DEPARTMENTS.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="w-full md:w-40">
          <select
            id="student-status-filter"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="On Leave">On Leave</option>
            <option value="Probation">Probation</option>
            <option value="Graduated">Graduated</option>
          </select>
        </div>

      </div>

      {/* Students Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-4">Department & Level</th>
                <th className="py-3 px-4 text-center">CGPA</th>
                <th className="py-3 px-4 text-center">Attendance</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    No student records match your query.
                  </td>
                </tr>
              ) : (
                filteredStudents.map(student => {
                  const att = getAttendanceForStudent(student.studentId);
                  return (
                    <tr 
                      key={student.id} 
                      className="hover:bg-slate-50/70 transition cursor-pointer"
                      onClick={() => setSelectedStudent(student)}
                    >
                      {/* Name & Avatar */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <img 
                            src={student.avatar} 
                            alt={student.name} 
                            className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200" 
                          />
                          <div>
                            <span className="font-bold text-slate-900 block leading-tight">{student.name}</span>
                            <span className="text-[11px] text-slate-400">{student.email}</span>
                          </div>
                        </div>
                      </td>

                      {/* ID */}
                      <td className="py-3.5 px-4 font-mono font-semibold text-slate-700">
                        {student.studentId}
                      </td>

                      {/* Department & Semester */}
                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-800 block">{student.department}</span>
                        <span className="text-[10px] text-slate-500">Sem {student.semester} • Year {student.year}</span>
                      </td>

                      {/* CGPA */}
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-block font-bold px-2 py-0.5 rounded text-xs ${
                          student.cgpa >= 3.7 
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : student.cgpa >= 3.0
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {student.cgpa.toFixed(2)}
                        </span>
                      </td>

                      {/* Attendance */}
                      <td className="py-3.5 px-4 text-center">
                        <span className={`font-semibold ${att.rate < 75 ? 'text-rose-600 font-bold' : 'text-slate-700'}`}>
                          {att.rate}%
                        </span>
                        {att.rate < 75 && (
                          <span className="block text-[9px] text-rose-500 font-bold">Alert: &lt;75%</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          student.status === 'Active' 
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : student.status === 'Probation'
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}>
                          {student.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            id={`view-student-${student.studentId}`}
                            onClick={() => setSelectedStudent(student)}
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-900 transition"
                            title="View Full Profile & Transcript"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                          {role === 'admin' && (
                            <button
                              id={`delete-student-${student.studentId}`}
                              onClick={() => deleteStudent(student.id)}
                              className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition"
                              title="Remove Student Record"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Profile & Transcript Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 animate-in fade-in zoom-in-95 p-6">
            
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center space-x-3">
                <img 
                  src={selectedStudent.avatar} 
                  alt={selectedStudent.name} 
                  className="w-14 h-14 rounded-full object-cover ring-2 ring-slate-200" 
                />
                <div>
                  <h2 className="text-lg font-bold text-slate-900">{selectedStudent.name}</h2>
                  <div className="flex items-center space-x-2 text-xs text-slate-500">
                    <span className="font-mono font-semibold">{selectedStudent.studentId}</span>
                    <span>•</span>
                    <span>{selectedStudent.department}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => window.print()}
                  className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
                  title="Print Summary"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedStudent(null)}
                  className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Academic Snapshot Cards */}
            <div className="grid grid-cols-3 gap-3 my-5">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">Cumulative CGPA</span>
                <span className="text-xl font-bold text-slate-900">{selectedStudent.cgpa.toFixed(2)}</span>
                <span className="text-[10px] text-slate-400 block">4.0 Scale</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">Credits Earned</span>
                <span className="text-xl font-bold text-slate-900">{selectedStudent.creditsCompleted}</span>
                <span className="text-[10px] text-slate-400 block">of 120 Total</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">Overall Attendance</span>
                <span className={`text-xl font-bold ${getAttendanceForStudent(selectedStudent.studentId).rate < 75 ? 'text-rose-600' : 'text-emerald-600'}`}>
                  {getAttendanceForStudent(selectedStudent.studentId).rate}%
                </span>
                <span className="text-[10px] text-slate-400 block">Min 75% required</span>
              </div>
            </div>

            {/* Student Contact & Academic Advisor */}
            <div className="space-y-3 text-xs mb-5">
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px]">Email Address:</span>
                  <span className="font-semibold text-slate-700">{selectedStudent.email}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Phone Number:</span>
                  <span className="font-semibold text-slate-700">{selectedStudent.phone}</span>
                </div>
                <div className="mt-2">
                  <span className="text-slate-400 block text-[10px]">Assigned Faculty Advisor:</span>
                  <span className="font-semibold text-slate-700">{selectedStudent.advisor}</span>
                </div>
                <div className="mt-2">
                  <span className="text-slate-400 block text-[10px]">Academic Standing:</span>
                  <span className="font-semibold text-slate-700">{selectedStudent.status}</span>
                </div>
              </div>
            </div>

            {/* Enrolled Courses */}
            <div className="mb-5">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                Enrolled Courses ({selectedStudent.enrolledCourseCodes.length})
              </h3>
              <div className="flex flex-wrap gap-2">
                {selectedStudent.enrolledCourseCodes.map(code => (
                  <span key={code} className="px-2.5 py-1 rounded bg-slate-100 border border-slate-200 font-semibold text-xs text-slate-800">
                    {code}
                  </span>
                ))}
              </div>
            </div>

            {/* Official Grade Records for this Student */}
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                Examination & Course Grades
              </h3>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-[10px] uppercase text-slate-500 font-semibold">
                    <tr>
                      <th className="p-2.5">Course</th>
                      <th className="p-2.5 text-center">Midterm (30)</th>
                      <th className="p-2.5 text-center">Final (50)</th>
                      <th className="p-2.5 text-center">Total (100)</th>
                      <th className="p-2.5 text-center">Grade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {grades.filter(g => g.studentId === selectedStudent.studentId).length === 0 ? (
                      <tr>
                        <td colSpan={5} className="text-center py-4 text-slate-400 text-[11px]">
                          No published course grades on file for current term.
                        </td>
                      </tr>
                    ) : (
                      grades.filter(g => g.studentId === selectedStudent.studentId).map(g => (
                        <tr key={g.id}>
                          <td className="p-2.5 font-bold text-slate-800">{g.courseCode}</td>
                          <td className="p-2.5 text-center text-slate-600">{g.midtermScore}</td>
                          <td className="p-2.5 text-center text-slate-600">{g.finalExamScore}</td>
                          <td className="p-2.5 text-center font-bold text-slate-900">{g.totalScore}</td>
                          <td className="p-2.5 text-center">
                            <span className="font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                              {g.letterGrade}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedStudent(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition"
              >
                Close Profile
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Add New Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">Register New Student</h2>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Julian Montgomery"
                  value={newStudent.name}
                  onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Student ID</label>
                  <input
                    type="text"
                    required
                    value={newStudent.studentId}
                    onChange={(e) => setNewStudent({ ...newStudent, studentId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 font-mono text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Institutional Email</label>
                  <input
                    type="email"
                    required
                    placeholder="j.montgomery@apex.edu"
                    value={newStudent.email}
                    onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={newStudent.department}
                    onChange={(e) => setNewStudent({ ...newStudent, department: e.target.value as Department })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
                  >
                    {DEPARTMENTS.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Semester & Year</label>
                  <div className="flex gap-2">
                    <select
                      value={newStudent.semester}
                      onChange={(e) => setNewStudent({ ...newStudent, semester: Number(e.target.value) })}
                      className="w-1/2 px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                        <option key={s} value={s}>Sem {s}</option>
                      ))}
                    </select>
                    <select
                      value={newStudent.year}
                      onChange={(e) => setNewStudent({ ...newStudent, year: Number(e.target.value) })}
                      className="w-1/2 px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                    >
                      {[1, 2, 3, 4].map(y => (
                        <option key={y} value={y}>Yr {y}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={newStudent.phone}
                    onChange={(e) => setNewStudent({ ...newStudent, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Faculty Advisor</label>
                  <input
                    type="text"
                    value={newStudent.advisor}
                    onChange={(e) => setNewStudent({ ...newStudent, advisor: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition"
                >
                  Register Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
