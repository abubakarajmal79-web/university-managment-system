import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { Announcement } from '../../types';
import { 
  Megaphone, 
  Search, 
  Plus, 
  Filter, 
  Calendar, 
  User, 
  Trash2, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  X,
  Tag
} from 'lucide-react';

export const AnnouncementsView: React.FC = () => {
  const { announcements, addAnnouncement, deleteAnnouncement, role } = useUniversity();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);

  const [newNotice, setNewNotice] = useState({
    title: '',
    content: '',
    author: role === 'faculty' ? 'Faculty Department Office' : 'Office of University Registrar',
    authorRole: role === 'faculty' ? 'Academic Department' : 'Administration',
    category: 'Academic' as Announcement['category'],
    priority: 'Standard' as Announcement['priority']
  });

  const filteredNotices = announcements.filter(notice => {
    const matchesSearch = 
      notice.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notice.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notice.author.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || notice.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const handlePublishSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNotice.title || !newNotice.content) return;

    addAnnouncement(newNotice);
    setIsPublishModalOpen(false);
    setNewNotice({
      title: '',
      content: '',
      author: 'Office of University Registrar',
      authorRole: 'Administration',
      category: 'Academic',
      priority: 'Standard'
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">University Notices & Campus Bulletins</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Official announcements from the Academic Senate, Examination Board, Bursar, and Campus Facilities.
          </p>
        </div>

        {role !== 'student' && (
          <button
            id="btn-publish-notice-modal"
            onClick={() => setIsPublishModalOpen(true)}
            className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Publish New Notice</span>
          </button>
        )}
      </div>

      {/* Filter & Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="notice-search-input"
            type="text"
            placeholder="Search campus bulletins by keyword, topic, or author..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
          />
        </div>

        <div className="w-full md:w-56">
          <select
            id="notice-category-filter"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="All">All Bulletin Categories</option>
            <option value="Academic">Academic Notices</option>
            <option value="Examination">Examinations & Schedules</option>
            <option value="Administrative">Administrative & Bursar</option>
            <option value="Events">Campus Events & Symposia</option>
          </select>
        </div>
      </div>

      {/* Announcements List */}
      <div className="space-y-4">
        {filteredNotices.length === 0 ? (
          <div className="bg-white p-12 text-center rounded-xl border border-slate-200 text-slate-400 text-xs">
            No announcements match your search or filter criteria.
          </div>
        ) : (
          filteredNotices.map(notice => (
            <div 
              key={notice.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    {/* Priority badge */}
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                      notice.priority === 'Urgent'
                        ? 'bg-rose-100 text-rose-800 border border-rose-200'
                        : notice.priority === 'Standard'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                    }`}>
                      {notice.priority}
                    </span>

                    {/* Category */}
                    <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                      {notice.category}
                    </span>

                    <span className="text-slate-300">•</span>
                    <span className="text-[11px] text-slate-400 font-medium">{notice.date}</span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 leading-snug">{notice.title}</h3>
                </div>

                {role === 'admin' && (
                  <button
                    onClick={() => deleteAnnouncement(notice.id)}
                    className="text-slate-400 hover:text-rose-600 p-1"
                    title="Delete Notice"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                {notice.content}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center space-x-1.5">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>Authorized by <strong className="text-slate-700 font-semibold">{notice.author}</strong> ({notice.authorRole})</span>
                </div>
                <span className="text-slate-400 font-mono text-[10px]">VERIFIED CIRCULAR</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Publish Notice Modal */}
      {isPublishModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">Publish Campus Notice</h2>
              <button 
                onClick={() => setIsPublishModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePublishSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Notice Headline</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mandatory Library RFID Card Re-validation"
                  value={newNotice.title}
                  onChange={(e) => setNewNotice({ ...newNotice, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={newNotice.category}
                    onChange={(e) => setNewNotice({ ...newNotice, category: e.target.value as Announcement['category'] })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="Academic">Academic</option>
                    <option value="Examination">Examination</option>
                    <option value="Administrative">Administrative</option>
                    <option value="Events">Events</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Priority Level</label>
                  <select
                    value={newNotice.priority}
                    onChange={(e) => setNewNotice({ ...newNotice, priority: e.target.value as Announcement['priority'] })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="General">General Information</option>
                    <option value="Standard">Standard Bulletin</option>
                    <option value="Urgent">Urgent Priority</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Author Name / Department</label>
                  <input
                    type="text"
                    required
                    value={newNotice.author}
                    onChange={(e) => setNewNotice({ ...newNotice, author: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Author Designation</label>
                  <input
                    type="text"
                    required
                    value={newNotice.authorRole}
                    onChange={(e) => setNewNotice({ ...newNotice, authorRole: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Circular Content</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Provide complete circular details, deadlines, and instructions..."
                  value={newNotice.content}
                  onChange={(e) => setNewNotice({ ...newNotice, content: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsPublishModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition"
                >
                  Publish Notice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
