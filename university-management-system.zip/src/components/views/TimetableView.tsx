import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { DEPARTMENTS } from '../../data/mockData';
import { Course } from '../../types';
import { 
  CalendarDays, 
  Clock, 
  MapPin, 
  UserCheck, 
  Filter, 
  Layers, 
  BookOpen,
  X
} from 'lucide-react';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] as const;
const TIME_SLOTS = [
  '09:00 - 10:30',
  '10:45 - 12:15',
  '11:00 - 12:30',
  '14:00 - 15:30',
  '14:00 - 16:00',
  '16:00 - 17:30',
];

export const TimetableView: React.FC = () => {
  const { courses, role, activeStudentId, students } = useUniversity();
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedCourseDetail, setSelectedCourseDetail] = useState<Course | null>(null);

  const activeStudent = students.find(s => s.studentId === activeStudentId);

  // Filter courses
  const filteredCourses = courses.filter(course => {
    if (role === 'student' && activeStudent) {
      // In student mode, option to view only their enrolled courses
      return activeStudent.enrolledCourseCodes.includes(course.code);
    }
    return selectedDept === 'All' || course.department === selectedDept;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            {role === 'student' ? 'My Weekly Class Schedule' : 'University Master Lecture Schedule'}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {role === 'student' 
              ? `Personalized timetable for ${activeStudent?.name} (${activeStudent?.department})`
              : 'Classroom allocations, recurring lecture blocks, and campus lab periods.'}
          </p>
        </div>

        {role !== 'student' && (
          <div className="w-full sm:w-64">
            <select
              id="timetable-dept-filter"
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden shadow-xs"
            >
              <option value="All">All University Departments</option>
              {DEPARTMENTS.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Weekly Visual Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        
        {/* Days Header */}
        <div className="grid grid-cols-5 border-b border-slate-200 bg-slate-50 text-xs font-bold text-slate-700 text-center">
          {DAYS.map(day => (
            <div key={day} className="py-3 px-2 border-r last:border-r-0 border-slate-200">
              <span className="block text-sm text-slate-900">{day}</span>
              <span className="text-[10px] text-slate-400 font-normal">
                {day === 'Mon' && 'Monday'}
                {day === 'Tue' && 'Tuesday'}
                {day === 'Wed' && 'Wednesday'}
                {day === 'Thu' && 'Thursday'}
                {day === 'Fri' && 'Friday'}
              </span>
            </div>
          ))}
        </div>

        {/* Schedule Columns */}
        <div className="grid grid-cols-5 min-h-[500px] divide-x divide-slate-200 bg-slate-50/30">
          {DAYS.map(day => {
            // Find all classes on this day
            const dayClasses = filteredCourses.flatMap(course => 
              course.schedule
                .filter(slot => slot.day === day)
                .map(slot => ({ course, slot }))
            );

            return (
              <div key={day} className="p-2 space-y-2.5">
                {dayClasses.length === 0 ? (
                  <div className="h-32 flex items-center justify-center text-slate-400 text-[11px] italic">
                    No scheduled lectures
                  </div>
                ) : (
                  dayClasses.map(({ course, slot }, idx) => (
                    <div
                      key={idx}
                      onClick={() => setSelectedCourseDetail(course)}
                      className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs hover:border-slate-400 transition cursor-pointer text-left space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-xs text-amber-600">{course.code}</span>
                        <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                          {course.credits} Cr
                        </span>
                      </div>

                      <h4 className="font-bold text-xs text-slate-900 leading-tight line-clamp-2">
                        {course.title}
                      </h4>

                      <div className="flex items-center space-x-1 text-[10px] text-slate-500 pt-1">
                        <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                        <span>{slot.time}</span>
                      </div>

                      <div className="flex items-center space-x-1 text-[10px] text-slate-500">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{slot.room}</span>
                      </div>

                      <div className="pt-1.5 border-t border-slate-100 text-[10px] text-slate-600 truncate">
                        {course.instructorName}
                      </div>
                    </div>
                  ))
                )}
              </div>
            );
          })}
        </div>

      </div>

      {/* Course Detail Modal */}
      {selectedCourseDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="font-mono text-xs font-bold text-amber-600">{selectedCourseDetail.code}</span>
                <h3 className="font-bold text-slate-900 text-base">{selectedCourseDetail.title}</h3>
              </div>
              <button 
                onClick={() => setSelectedCourseDetail(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Department & Credits:</span>
                <span className="font-semibold text-slate-800">{selectedCourseDetail.department} • {selectedCourseDetail.credits} Credits</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Instructor:</span>
                <span className="font-semibold text-slate-800">{selectedCourseDetail.instructorName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Class Schedule:</span>
                <div className="space-y-1 mt-1">
                  {selectedCourseDetail.schedule.map((s, i) => (
                    <div key={i} className="p-2 rounded bg-slate-50 border border-slate-200 text-slate-700 flex justify-between">
                      <span className="font-semibold">{s.day} {s.time}</span>
                      <span className="text-slate-500">{s.room}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Syllabus Summary:</span>
                <p className="text-slate-600 mt-0.5 leading-relaxed bg-slate-50 p-2.5 rounded border border-slate-200">
                  {selectedCourseDetail.syllabus}
                </p>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedCourseDetail(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
