import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { Faculty, Department } from '../../types';
import { DEPARTMENTS } from '../../data/mockData';
import { 
  GraduationCap, 
  Search, 
  Plus, 
  Mail, 
  Phone, 
  MapPin, 
  BookOpen, 
  Award, 
  Sparkles,
  Trash2,
  X
} from 'lucide-react';

export const FacultyView: React.FC = () => {
  const { faculty, addFaculty, deleteFaculty, role } = useUniversity();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const [newFaculty, setNewFaculty] = useState({
    facultyId: `FAC-${100 + faculty.length + 1}`,
    name: '',
    email: '',
    department: 'Computer Science & AI' as Department,
    designation: 'Assistant Professor' as Faculty['designation'],
    office: 'Academic Block C, Room 201',
    phone: '+1 (555) 701-0000',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    specializedFields: ['Machine Learning', 'Computer Systems'],
    courseCodes: ['CS-301']
  });

  const [specialtyInput, setSpecialtyInput] = useState('');

  const filteredFaculty = faculty.filter(f => {
    const matchesSearch = 
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.specializedFields.some(field => field.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesDept = selectedDept === 'All' || f.department === selectedDept;

    return matchesSearch && matchesDept;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFaculty.name || !newFaculty.email) return;

    addFaculty(newFaculty);
    setIsAddModalOpen(false);
    setNewFaculty({
      facultyId: `FAC-${100 + faculty.length + 2}`,
      name: '',
      email: '',
      department: 'Computer Science & AI',
      designation: 'Assistant Professor',
      office: 'Academic Block C, Room 201',
      phone: '+1 (555) 701-0000',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      specializedFields: ['Machine Learning', 'Computer Systems'],
      courseCodes: ['CS-301']
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Academic Faculty & Staff Directory</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Profiles of university deans, tenured professors, research fellows, and departmental lecturers.
          </p>
        </div>

        {role === 'admin' && (
          <button
            id="btn-add-faculty-modal"
            onClick={() => setIsAddModalOpen(true)}
            className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Add Faculty Member</span>
          </button>
        )}
      </div>

      {/* Filter & Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="faculty-search-input"
            type="text"
            placeholder="Search faculty by name, specialization, or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-slate-900 text-slate-800"
          />
        </div>

        <div className="w-full md:w-64">
          <select
            id="faculty-dept-filter"
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="All">All Academic Departments</option>
            {DEPARTMENTS.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Faculty Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredFaculty.map(member => (
          <div 
            key={member.id} 
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition flex flex-col justify-between"
          >
            <div>
              {/* Member Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <img 
                    src={member.avatar} 
                    alt={member.name} 
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-slate-200" 
                  />
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 leading-tight">{member.name}</h3>
                    <span className="text-[11px] font-semibold text-indigo-600 block">{member.designation}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{member.facultyId}</span>
                  </div>
                </div>

                {role === 'admin' && (
                  <button
                    onClick={() => deleteFaculty(member.id)}
                    className="text-slate-400 hover:text-rose-600 p-1"
                    title="Remove Faculty"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Department badge */}
              <div className="mt-3">
                <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                  {member.department}
                </span>
              </div>

              {/* Office & Contact info */}
              <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center space-x-2 text-[11px]">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{member.office}</span>
                </div>
                <div className="flex items-center space-x-2 text-[11px]">
                  <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{member.email}</span>
                </div>
                <div className="flex items-center space-x-2 text-[11px]">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{member.phone}</span>
                </div>
              </div>

              {/* Research Specialties */}
              <div className="mt-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                  Research & Specialties
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {member.specializedFields.map(field => (
                    <span key={field} className="text-[10px] px-2 py-0.5 rounded-full bg-slate-50 border border-slate-200 text-slate-600 font-medium">
                      {field}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Courses Teaching Footer */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 text-[11px]">Assigned Courses:</span>
              <div className="flex gap-1">
                {member.courseCodes.map(c => (
                  <span key={c} className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                    {c}
                  </span>
                ))}
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Add Faculty Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">Add Academic Faculty Member</h2>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name & Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Catherine Brooks"
                  value={newFaculty.name}
                  onChange={(e) => setNewFaculty({ ...newFaculty, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Faculty ID</label>
                  <input
                    type="text"
                    required
                    value={newFaculty.facultyId}
                    onChange={(e) => setNewFaculty({ ...newFaculty, facultyId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Academic Email</label>
                  <input
                    type="email"
                    required
                    placeholder="c.brooks@apex.edu"
                    value={newFaculty.email}
                    onChange={(e) => setNewFaculty({ ...newFaculty, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={newFaculty.department}
                    onChange={(e) => setNewFaculty({ ...newFaculty, department: e.target.value as Department })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    {DEPARTMENTS.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Designation</label>
                  <select
                    value={newFaculty.designation}
                    onChange={(e) => setNewFaculty({ ...newFaculty, designation: e.target.value as Faculty['designation'] })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="Department Dean">Department Dean</option>
                    <option value="Professor">Professor</option>
                    <option value="Associate Professor">Associate Professor</option>
                    <option value="Assistant Professor">Assistant Professor</option>
                    <option value="Lecturer">Lecturer</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Office Location</label>
                <input
                  type="text"
                  value={newFaculty.office}
                  onChange={(e) => setNewFaculty({ ...newFaculty, office: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Specialized Fields (Comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Autonomous Robotics, Embedded IoT, Control Theory"
                  value={specialtyInput}
                  onChange={(e) => {
                    setSpecialtyInput(e.target.value);
                    setNewFaculty({
                      ...newFaculty,
                      specializedFields: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    });
                  }}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition"
                >
                  Add Faculty
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
