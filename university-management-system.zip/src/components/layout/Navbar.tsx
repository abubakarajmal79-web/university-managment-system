import React, { useState } from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { UserRole } from '../../types';
import { 
  GraduationCap, 
  ShieldCheck, 
  UserCheck, 
  Users, 
  Bell, 
  RotateCcw, 
  Calendar,
  Search,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';

interface NavbarProps {
  onSearchClick?: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ setActiveTab }) => {
  const { 
    role, 
    setRole, 
    activeStudentId, 
    setActiveStudentId, 
    activeFacultyId, 
    setActiveFacultyId,
    students, 
    faculty, 
    announcements,
    resetToDemoData 
  } = useUniversity();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const activeStudent = students.find(s => s.studentId === activeStudentId) || students[0];
  const activeFacultyMember = faculty.find(f => f.id === activeFacultyId) || faculty[0];

  const urgentCount = announcements.filter(a => a.priority === 'Urgent').length;

  return (
    <header id="app-navbar" className="bg-white border-b border-slate-200 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & University Identity */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center text-white shadow-sm ring-1 ring-slate-900/10">
              <GraduationCap className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg text-slate-900 tracking-tight">APEX UNIVERSITY</span>
                <span className="text-[11px] font-semibold uppercase px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                  EST. 1884
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium hidden sm:block">Unified Academic Management System</p>
            </div>
          </div>

          {/* Current Academic Term Badge */}
          <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-md bg-slate-50 border border-slate-200 text-xs font-medium text-slate-600">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Fall Semester 2026</span>
            <span className="text-slate-300">•</span>
            <span className="text-emerald-600 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Academic Week 3
            </span>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-3">
            
            {/* Role Switcher Pill Group */}
            <div className="bg-slate-100 p-1 rounded-lg flex items-center border border-slate-200 text-xs font-semibold">
              <button
                id="role-admin-btn"
                onClick={() => setRole('admin')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
                  role === 'admin' 
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60 font-bold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Administrator View"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Admin</span>
              </button>

              <button
                id="role-faculty-btn"
                onClick={() => setRole('faculty')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
                  role === 'faculty' 
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60 font-bold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Faculty View"
              >
                <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden sm:inline">Faculty</span>
              </button>

              <button
                id="role-student-btn"
                onClick={() => setRole('student')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
                  role === 'student' 
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60 font-bold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Student Portal View"
              >
                <Users className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">Student</span>
              </button>
            </div>

            {/* Persona Switcher Dropdown (When Faculty or Student is active) */}
            {role === 'student' && (
              <div className="hidden lg:flex items-center space-x-1.5 bg-slate-50 border border-slate-200 rounded-md px-2 py-1 text-xs">
                <span className="text-slate-500">Student:</span>
                <select
                  id="student-persona-select"
                  value={activeStudentId}
                  onChange={(e) => setActiveStudentId(e.target.value)}
                  className="bg-transparent font-semibold text-slate-800 focus:outline-hidden cursor-pointer"
                >
                  {students.map(s => (
                    <option key={s.id} value={s.studentId}>
                      {s.name} ({s.department.split(' ')[0]})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {role === 'faculty' && (
              <div className="hidden lg:flex items-center space-x-1.5 bg-slate-50 border border-slate-200 rounded-md px-2 py-1 text-xs">
                <span className="text-slate-500">Instructor:</span>
                <select
                  id="faculty-persona-select"
                  value={activeFacultyId}
                  onChange={(e) => setActiveFacultyId(e.target.value)}
                  className="bg-transparent font-semibold text-slate-800 focus:outline-hidden cursor-pointer"
                >
                  {faculty.map(f => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.department.split(' ')[0]})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Notifications Bell */}
            <div className="relative">
              <button
                id="notifications-bell-btn"
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition relative"
                aria-label="View notifications"
              >
                <Bell className="w-5 h-5" />
                {urgentCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white"></span>
                )}
              </button>

              {/* Notification Dropdown */}
              {showNotifications && (
                <div 
                  id="notifications-dropdown"
                  className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2"
                >
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="font-semibold text-sm text-slate-800">Campus Bulletins</span>
                    <button 
                      onClick={() => { setShowNotifications(false); setActiveTab('announcements'); }}
                      className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
                    >
                      View All ({announcements.length})
                    </button>
                  </div>
                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                    {announcements.slice(0, 4).map(ann => (
                      <div key={ann.id} className="p-3 hover:bg-slate-50 transition">
                        <div className="flex items-center space-x-2">
                          {ann.priority === 'Urgent' ? (
                            <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0"></span>
                          )}
                          <span className="font-semibold text-xs text-slate-800 line-clamp-1">{ann.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{ann.content}</p>
                        <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400">
                          <span>{ann.author}</span>
                          <span>{ann.date}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Reset to Demo Data Button */}
            <button
              id="reset-demo-btn"
              onClick={() => setShowResetConfirm(true)}
              className="p-2 rounded-md text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
              title="Reset to Demo State"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* User Profile Avatar */}
            <div className="flex items-center pl-2 border-l border-slate-200">
              {role === 'student' ? (
                <div className="flex items-center space-x-2">
                  <img 
                    src={activeStudent.avatar} 
                    alt={activeStudent.name} 
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-300" 
                  />
                  <div className="hidden xl:block text-left text-xs">
                    <p className="font-semibold text-slate-800 leading-tight">{activeStudent.name}</p>
                    <p className="text-[10px] text-slate-500">{activeStudent.studentId}</p>
                  </div>
                </div>
              ) : role === 'faculty' ? (
                <div className="flex items-center space-x-2">
                  <img 
                    src={activeFacultyMember.avatar} 
                    alt={activeFacultyMember.name} 
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-300" 
                  />
                  <div className="hidden xl:block text-left text-xs">
                    <p className="font-semibold text-slate-800 leading-tight">{activeFacultyMember.name}</p>
                    <p className="text-[10px] text-slate-500">{activeFacultyMember.designation}</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-xs ring-1 ring-slate-300">
                    AD
                  </div>
                  <div className="hidden xl:block text-left text-xs">
                    <p className="font-semibold text-slate-800 leading-tight">Academic Dean's Office</p>
                    <p className="text-[10px] text-slate-500">Super Administrator</p>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-4 border border-amber-200">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-center font-bold text-slate-900 text-lg mb-2">Reset Demo Database?</h3>
            <p className="text-center text-xs text-slate-600 mb-6">
              This will restore all default mock students, faculty, course enrollments, attendance marks, and invoices to their original status.
            </p>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetToDemoData();
                  setShowResetConfirm(false);
                }}
                className="flex-1 px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 transition"
              >
                Yes, Reset All
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
