import React from 'react';
import { useUniversity } from '../../context/UniversityContext';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  BookOpen, 
  CheckSquare, 
  Award, 
  CreditCard, 
  CalendarDays, 
  Megaphone,
  Building2,
  HelpCircle,
  ExternalLink,
  PhoneCall
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, isOpen, setIsOpen }) => {
  const { role } = useUniversity();

  const adminNavItems = [
    { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard },
    { id: 'students', label: 'Students Directory', icon: Users },
    { id: 'faculty', label: 'Faculty & Instructors', icon: GraduationCap },
    { id: 'courses', label: 'Courses & Curriculum', icon: BookOpen },
    { id: 'attendance', label: 'Attendance System', icon: CheckSquare },
    { id: 'gradebook', label: 'Gradebook & Exams', icon: Award },
    { id: 'fees', label: 'Tuition & Finance', icon: CreditCard },
    { id: 'timetable', label: 'Master Timetable', icon: CalendarDays },
    { id: 'announcements', label: 'Campus Bulletins', icon: Megaphone },
  ];

  const facultyNavItems = [
    { id: 'dashboard', label: 'Faculty Overview', icon: LayoutDashboard },
    { id: 'courses', label: 'My Assigned Classes', icon: BookOpen },
    { id: 'attendance', label: 'Mark Attendance', icon: CheckSquare },
    { id: 'gradebook', label: 'Grade Entry & Review', icon: Award },
    { id: 'timetable', label: 'Teaching Schedule', icon: CalendarDays },
    { id: 'announcements', label: 'University Bulletins', icon: Megaphone },
  ];

  const studentNavItems = [
    { id: 'dashboard', label: 'My Academic Hub', icon: LayoutDashboard },
    { id: 'courses', label: 'Enrolled Courses', icon: BookOpen },
    { id: 'attendance', label: 'Attendance Record', icon: CheckSquare },
    { id: 'gradebook', label: 'Grades & Transcript', icon: Award },
    { id: 'fees', label: 'Tuition Invoices', icon: CreditCard },
    { id: 'timetable', label: 'My Class Schedule', icon: CalendarDays },
    { id: 'announcements', label: 'Campus Notices', icon: Megaphone },
  ];

  const navItems = role === 'admin' 
    ? adminNavItems 
    : role === 'faculty' 
      ? facultyNavItems 
      : studentNavItems;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 z-20 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside 
        id="app-sidebar"
        className={`fixed md:sticky top-16 left-0 z-20 w-64 h-[calc(100vh-4rem)] bg-white border-r border-slate-200 flex flex-col justify-between transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Navigation Items */}
        <div className="p-4 space-y-6 overflow-y-auto">
          
          <div>
            <div className="px-3 mb-2 flex items-center justify-between">
              <span className="text-[11px] font-bold tracking-wider text-slate-400 uppercase">
                {role === 'admin' ? 'University Management' : role === 'faculty' ? 'Faculty Portal' : 'Student Portal'}
              </span>
            </div>

            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-${item.id}`}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsOpen(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                      isActive 
                        ? 'bg-slate-900 text-white shadow-xs' 
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Institutional Campus Info Box */}
          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
            <div className="flex items-center space-x-2 text-slate-800 text-xs font-bold mb-1">
              <Building2 className="w-4 h-4 text-slate-500" />
              <span>Apex Main Campus</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Academic Senate session scheduled for Oct 15 in Senate Hall.
            </p>
            <div className="mt-2.5 pt-2.5 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500">
              <span>Registrar Help Desk</span>
              <span className="font-semibold text-slate-700">Ext. 2040</span>
            </div>
          </div>

        </div>

        {/* Footer Support & Help */}
        <div className="p-4 border-t border-slate-200 bg-slate-50/50">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center space-x-1.5">
              <PhoneCall className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[11px]">Emergency: 911 / Ext. 9</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-mono">
              v2.4.0
            </span>
          </div>
        </div>
      </aside>
    </>
  );
};
