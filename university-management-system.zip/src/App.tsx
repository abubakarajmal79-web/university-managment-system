import React, { useState } from 'react';
import { UniversityProvider, useUniversity } from './context/UniversityContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { StudentsView } from './components/views/StudentsView';
import { FacultyView } from './components/views/FacultyView';
import { CoursesView } from './components/views/CoursesView';
import { AttendanceView } from './components/views/AttendanceView';
import { GradebookView } from './components/views/GradebookView';
import { FeesFinanceView } from './components/views/FeesFinanceView';
import { TimetableView } from './components/views/TimetableView';
import { AnnouncementsView } from './components/views/AnnouncementsView';
import { StudentPortalView } from './components/views/StudentPortalView';
import { Menu, X } from 'lucide-react';

const MainContent: React.FC = () => {
  const { role } = useUniversity();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Render view based on activeTab and role
  const renderView = () => {
    // If student is on dashboard, show dedicated personalized StudentPortalView
    if (activeTab === 'dashboard') {
      if (role === 'student') {
        return <StudentPortalView setActiveTab={setActiveTab} />;
      }
      return <DashboardView setActiveTab={setActiveTab} />;
    }

    switch (activeTab) {
      case 'students':
        return <StudentsView />;
      case 'faculty':
        return <FacultyView />;
      case 'courses':
        return <CoursesView />;
      case 'attendance':
        return <AttendanceView />;
      case 'gradebook':
        return <GradebookView />;
      case 'fees':
        return <FeesFinanceView />;
      case 'timetable':
        return <TimetableView />;
      case 'announcements':
        return <AnnouncementsView />;
      default:
        return <DashboardView setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      
      {/* Top Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Mobile Sidebar Toggle Button */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 text-xs font-semibold"
        >
          {sidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Menu</span>
        </button>
        <span className="text-xs font-bold text-slate-700 capitalize">
          {activeTab.replace('_', ' ')}
        </span>
      </div>

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Navigation Sidebar */}
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          isOpen={sidebarOpen} 
          setIsOpen={setSidebarOpen} 
        />

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
          {renderView()}
        </main>

      </div>

    </div>
  );
};

export default function App() {
  return (
    <UniversityProvider>
      <MainContent />
    </UniversityProvider>
  );
}
